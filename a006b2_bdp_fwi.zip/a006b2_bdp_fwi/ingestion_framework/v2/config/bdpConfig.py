### Ops Logical parameters for Ingestion Framework ###

# Version of the Ingestion Framework
cVersion = "v2"
# Unix Folders
cCommonDir = "/data/dev01/" # Renamed from cCommonPath
# Atlas
cAtlasDomain = "auslslnxsd2477.radtest.wbctestau.westpac.com.au"
cAtlasPort = "21443"
cAtlasTypePrefix = "d_"
# HBase
cHBaseDomain = "auslslnxsd2477.radtest.wbctestau.westpac.com.au"
cHBasePort = "8080"
cHBaseNamespace = "BDPD01META"
# Hive
cHiveDBPrefix = "bdpd01"
# HDFS
cNameNodeDomain = "auslslnxsd2477.radtest.wbctestau.westpac.com.au"
cNameNodePort = "8020"
cClusterName = "ibmbdp_sandbox_nonprod_5node"
cCommonHDFSDir= "/dev01/"

### FRAMEWORK Configuration ###

# HDFS
cNameNodeURI = "hdfs://" + cNameNodeDomain + ":" + cNameNodePort
cLandingHDFS = cCommonHDFSDir + "landing/"
cRawHDFS = cCommonHDFSDir + "raw/" 
cIntegratedHDFS = cCommonHDFSDir + "integrated/" 
cPublishHDFS = cCommonHDFSDir + "publish/"
# Framework Folders
cFrameworkDir = cCommonDir + "ingestion_framework/" + cVersion + "/"
cConfigDir = cFrameworkDir + "config/"
cCodeDir = cFrameworkDir + "code/" # Renamed from cCodePath
cUtilDir = cFrameworkDir + "util/"
cDBConnPath = cFrameworkDir + "jdbc/" # Renamed from cDBConnPath
cLogDir = cCommonDir + "logs/ingestion/" # Renamed from cLog
# Hive
cRawHiveDB = cHiveDBPrefix + "raw"
cIntegratedHiveDB = cHiveDBPrefix + "int"
cPublishHiveDB = cHiveDBPrefix + "pub"
# Exchange Folders
cInboundDir = cCommonDir + "in_bound/" # Renamed from cInboundPath
cOutboundDir = cCommonDir + "out_bound/" # Renamed from  cOutboundPath
cMetadataInboundDir = cCommonDir + "metadata/in_bound/" # Renamed from cInboundPath
cMetadataOutboundDir = cCommonDir + "metadata/out_bound/" # Renamed from  cOutboundPath
# Atlas
cAtlasURL = "https://" + cAtlasDomain + ":" + cAtlasPort + "/"
cAtlasQualifiedNameSeparator="@" # Renamed from cQualifiedSeparator
cAtlasTypeSource = cAtlasTypePrefix + 'bdp_SOR'
cAtlasTypeDataset = cAtlasTypePrefix + 'bdp_IngestionDataset'
cAtlasTypeAttribute = cAtlasTypePrefix + 'bdp_IngestionAttribute'
cAtlasTypeRule = cAtlasTypePrefix + 'bdp_IngestionRule' # Renamed from cAtlasRuleSet
cAtlasTypeProcess = cAtlasTypePrefix + 'bdp_Process' # Need to create this Process
cAtlasTypeHDFSPath = "hdfs_path"
cAtlasEntitycolumnA = "IngestionDataset"
cAtlasEntitycolumnB = "name"
cAtlasEntitycolumnC = "qualifiedName"
cAtlasUser = "admin" # Deprecate and move to pycurl
cAtlasPassword = "admin" # Deprecate and move to pycurl
cAtlasRuleDAType="assurance" # Renamed from cAtlasType
# Atlas CICD
cAtlasInDir = cMetadataInboundDir + 'atlas/'
cAtlasTypeDir = cAtlasInDir + "type/"
cAtlasEntityDir = cAtlasInDir + "entity/"
cAtlasArchiveDir = cAtlasInDir + "archive/entity/"
cAtlasHiveDir = cAtlasEntityDir + "hive/"
cMetadataDir = cAtlasInDir + "driver_files/" # Removed cicd word Renamed from cCommonDriverFilePath
# IMM File generation
cIMMOutDir = cMetadataOutboundDir + 'imm/'
cIMMOutTempDir = cAtlasEntityDir + 'imm/'
cIMMInstanceList = ["DATA_PROV_FILE","DATA_PROV_DB","HDFS_LANDING","HDFS_RAW","HIVE_RAW"]
cIMMAppBaseFolder = "MM/BDP/"
cInstanceFileName = cIMMOutTempDir + 'LOAD_BDP_INSTANCES.csv'
cAttributeFileName = cIMMOutTempDir + 'LOAD_BDP_ATTRIBUTES.csv'
cFolderFileName = cIMMOutTempDir + 'LOAD_BDP_FOLDERS.csv'
cEntityFileName = cIMMOutTempDir + 'LOAD_BDP_ENTITIES.csv'
# FileNames and hard coded config Values used for generating json files # Please archive the CSVs as well
cSourceDriverFile = cMetadataDir + 'jsonMetadataSourceMaster.csv'
cDatasetDriverFile= cMetadataDir + "jsonMetadataDatasetMaster.csv"
cAttributeDriverFile = cMetadataDir + 'jsonMetadataAttributeMaster.csv'
cRuleDriverFile = cMetadataDir + 'jsonMetadataRuleMaster.csv'
cAllowedMetadataTypes = ['rule','attribute','dataset','source','process','hdfs_path']
cUploadSeqMetadataTypes = ['source','dataset','attribute','rule','process','imm']
cIMMTypes = ['Systems','Instances','Entities','Attributes','Folders','Mappings','Lineage']
cCreateDBFileName = "createDB"
#cCommonOutFilePath = cCommonInFileDir # Renamed path to JSON dir
cDatasetJSONDir = cAtlasEntityDir+"dataset/"
cSourceJSONDir = cAtlasEntityDir+"source/"
cAttributeOutJSONDir = cAtlasEntityDir + "attribute/"
cHDFSPathJSONDir = cAtlasEntityDir + "hdfs_path/" # Renamed from cHDFSLand
cProcessJSONDir = cAtlasEntityDir + "process/"
cRuleJSONDir = cAtlasEntityDir + "rule/"
cCreateDBDir = cAtlasEntityDir + "hive/"
cHQLFileExt = ".hql"
cTextFileExt = ".txt"
cJsonExtension = ".json"
cQuoteChar = '\"'
# HBase
cHBaseURL ="https://" + cHBaseDomain + ":" + cHBasePort + "/"
cSnapRun ="SNAP_SCHEDULE_RUN"
# PySpark
cExportCmd = "export SPARK_HOME=/usr/hdp/current/spark2-client; export SPARK_MAJOR_VERSION=2;" # Renamed export_cmd
cHiveXmlPath = "/usr/hdp/current/spark2-client/conf/hive-site.xml"
cCSVSep = "," # Renamed from csvSep
cSORDatasetType = ['file', 'db'] # Renamed from cMetadataSORDatasetType
cExtractTimestampFormat = ['%Y%m%d%H%M%S']
cdeployModeCluster = "cluster"
cdeployModeClient = "client"
cAtlasSparkJar=cUtilDir+"vhive.jar"
cDBSparkJar = "/usr/hdp/current/sqoop-server/lib/tdgssconfig.jar" + cCSVSep + "/usr/hdp/current/sqoop-server/lib/terajdbc4.jar"
cSparkFile = cCodeDir + "bdpSparkFlatFile.py"
#cSparkDb=cCodePath+"spark_RDBMS_code_v1.py"
sCSVfileFormat = "csv" #todo
cExecModeL = "local[*]"
cExecModeY = "yarn"
cPySparkConfig = cConfigDir + "bdpConfig.py" + cCSVSep + cUtilDir + "bdpSpark.py" # Renamed from cPyConfigFile
cOpCol = ['bdp_sor_extracttimestamp','bdp_actiontype','bdp_processcode','bdp_processmessage','bdp_createtimestamp', 'bdp_rowstatus', 'bdp_updatetimestamp']
cOpTimeStampCol = ['bdp_sor_extracttimestamp','bdp_createtimestamp','bdp_updatetimestamp']
 # Renamed from sihOpCol
cLoadType = ['oneoff','ongoing'] # Renamed from cTypeModedef and values from one & off
# Log file names
cLogFileJsonLoader = 'bdpAtlasJsonLoader' # Renamed the next 4 to log
cLogFileGenAllJSON = 'bdpAllJsonProcess'
cLogFileMasterCICD = 'bdpMasterCICDProcess'
cLogFileIMM = 'bdpGenerateIMMExtracts'
cLogBdpMasterTrigger='bdpMasterTrigger'
cLogBdpMasterTriggerFile='bdpMasterTriggerPy'

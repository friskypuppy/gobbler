cVersion="v2"
cCommonDir="/data/dev01/"
# Framework Folders
cFrameworkDir=$cCommonDir"ingestion_framework/"$cVersion"/"

cLogDir=$cCommonDir"logs/ingestion/"
cCodeDir=$cFrameworkDir"code/"
cPyScript=$cFrameworkDir"code/bdpMasterTrigger.py"
cConfigDir=$cFrameworkDir"config/"
cUtilDir=$cFrameworkDir"util/"

cLogBdpMasterWrapper=bdpMasterWrapper

##### CONTROL M ########
cInboundDir=$cCommonDir"in_bound/"
cLogFileName="bdpCtrlMInboundFile"


if [ $# -eq 1 ]
then
	echo "Root Directory received as: $1 "
	rootDir=$1
elif [ $# -eq 0 ]
then
	echo "No Root Directory received."
	echo "Provide a root directory like /data/dev01/ . Waiting for input......."
	read rootDir
else
	echo "Root Directory as a single argument expected"
fi

for i in `cat dir_list.txt`
do
	vDir=$1$i
	if [ -d $vDir ]
	then
		echo "$vDir exists. Changing mode."
		chmod 777 $vDir
		if [ $? -ne 0 ]
		then	
			echo " Could not change mode of $vDir"
		fi
	else
		echo "$vDir does not exist. Creating and changing mode."
		mkdir $vDir
		chmod 777 $vDir
	fi
done

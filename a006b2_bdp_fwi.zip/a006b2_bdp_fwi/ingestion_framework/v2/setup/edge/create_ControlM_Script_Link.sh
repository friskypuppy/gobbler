if [ $# -eq 1 ]
then
	echo "Root Directory received as: $1 "
	rootDir=$1
elif [ $# -eq 0 ]
then
	echo "No Root Directory received."
	echo "Provide a root directory like /data/dev01/ . Waiting for input......."
	read rootDir
else
	echo "Root Directory as a single argument expected"
fi	


echo "Creating Soft Link for the Control-M Inbound wrapper."
ln -s $rootDir"/ingestion_framework/v2/code/bdpCtlMInboundFile.sh" $rootDir"/ingestion_framework/bdpCtlMInboundFile.sh"
if [ $? -eq 0 ]
then
	echo "Soft Link created for Control-M Inbound wrapper."
else
	echo "Error creating Soft Link for Control-M Inbound wrapper."
fi

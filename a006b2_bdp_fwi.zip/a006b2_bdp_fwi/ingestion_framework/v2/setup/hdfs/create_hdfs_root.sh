hadoop fs -mkdir /dev01/landing
hadoop fs -chmod 777 /dev01/landing
hadoop fs -mkdir /dev01/raw
hadoop fs -chmod 777 /dev01/raw
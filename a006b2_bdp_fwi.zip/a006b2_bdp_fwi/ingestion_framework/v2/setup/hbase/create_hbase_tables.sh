# Create table Snap Run
echo "create_namespace 'BDPD01META'" | hbase shell
# Create table Snap Run
echo "create 'BDPD01META:INGESTION_RUN_LOG', 'TARGET', 'SOURCE', {NAME => 'LOG', VERSIONS => 300} " | hbase shell
# Create table Snap Latest
echo "create 'BDPD01META:INGESTION_RUN_SUMMARY', 'TARGET', 'INFO'" | hbase shell

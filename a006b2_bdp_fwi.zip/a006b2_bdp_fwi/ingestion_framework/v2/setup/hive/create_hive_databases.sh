# Create Raw Database
hive -e "create database bdpd01raw"

# Create Publish database
hive -e "create database bdpd01pub"

# SOR Type POST V1
curl --negotiate -u : -vvv -X POST \
-H "Accept: application/json" \
-H "Content-Type: application/json" \
-d @d_bdp_SOR_V1.json \
'https://auslslnxsd2477.radtest.wbctestau.westpac.com.au:21443/api/atlas/types'

# Dataset Type POST V1
curl --negotiate -u : -vvv -X POST \
-H "Accept: application/json" \
-H "Content-Type: application/json" \
-d @d_bdp_IngestionDataset_V1.json \
'https://auslslnxsd2477.radtest.wbctestau.westpac.com.au:21443/api/atlas/types'

# Attribute Type POST V1
curl --negotiate -u : -vvv -X POST \
-H "Accept: application/json" \
-H "Content-Type: application/json" \
-d @d_bdp_IngestionAttribute_V1.json \
'https://auslslnxsd2477.radtest.wbctestau.westpac.com.au:21443/api/atlas/types'


# Rule Type POST V1
curl --negotiate -u : -vvv -X POST \
-H "Accept: application/json" \
-H "Content-Type: application/json" \
-d @d_bdp_IngestionRule_V1.json \
'https://auslslnxsd2477.radtest.wbctestau.westpac.com.au:21443/api/atlas/types'

# Process Type POST V1
curl --negotiate -u : -vvv -X POST \
-H "Accept: application/json" \
-H "Content-Type: application/json" \
-d @d_bdp_Process_V1.json \
'https://auslslnxsd2477.radtest.wbctestau.westpac.com.au:21443/api/atlas/types'


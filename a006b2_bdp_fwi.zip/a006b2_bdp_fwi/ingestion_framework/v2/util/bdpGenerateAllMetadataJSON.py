
############################################################################################################################
# Script Name    : generateAllMetadataJson.py
# Description    : This python script is responsible generate Metadata JSON files to be ingested into ATLAS
# Author         : Cognizant Technology Solutions
############################################################################################################################



##################################
#     Import Libraries 1
##################################

import csv
import sys
import time
import datetime
import bdpJSONParse
import os
import logging
import subprocess
import shutil
import glob
import re
import inspect


#sys.path.append('/home/cogetl-npr/dev01/ingestion_framework/config/')
#from bdpConfig import *
sys.path.append('/data/mgpoc/dev01/ingestion_framework/v2/config')
from bdpConfig import *

###################################
#   Declare Global Variable
###################################

vTS = time.time()
vShortTime = datetime.datetime.fromtimestamp(vTS).strftime('%Y-%m-%dT%H:%M:%S.000Z')
vShortTimeFileName = datetime.datetime.fromtimestamp(vTS).strftime('%Y%m%d%H').replace('-','')
vCounter= 0
vFilePrefixTime   = datetime.datetime.fromtimestamp(vTS).strftime('%Y%m%d')
vFinalGUIDArray = ""
sTempGUIDArray = ""


##################################
#     Logging Set up
##################################
sArchiveFolderName = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')

# Check for Archive Folder or else create it
sFolderCheckFlag = os.path.isdir(cLogDir+sArchiveFolderName+"/bdpAtlas/")

if sFolderCheckFlag == False:
	os.makedirs(cLogDir+sArchiveFolderName+"/bdpAtlas/")
logfile = cLogDir+sArchiveFolderName+"/bdpAtlas/"+cLogFileGenAllJSON+"_"+vShortTimeFileName+".log"
logger = logging.getLogger(cLogFileGenAllJSON)
logger.setLevel(logging.DEBUG)
# create file handler which logs even debug messages
fh = logging.FileHandler(logfile)
fh.setLevel(logging.DEBUG)
# creating console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.ERROR)
# creating formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
fh.setFormatter(formatter)
# adding the handlers to logger
logger.addHandler(ch)
logger.addHandler(fh)


pInFunc = sys.argv[1] # Action item like source/dataset/attribute/rule/process

logger.info('Starting JSON generation sub module')
logger.info('Argument recieved as action item: '+pInFunc)


###################################
#   source
###################################
if pInFunc == "source":

	# Loop through each dataset to fetch the corresponding GUID from ATLAS     #
	sDatasetFile = open(cSourceDriverFile,'rb')
	ep = csv.DictReader(sDatasetFile, delimiter=',', quotechar = cQuoteChar)
	
	for e_loop_var in ep:
			
		# Read the each source entry
		sName = (e_loop_var['name'])
		sDescription = (e_loop_var['description'])
		sAbbreviation = (e_loop_var['abbreviation'])
		sOwner = (e_loop_var['owner'])
		sAction = (e_loop_var['action'])
		#sTypeName = cTypePrefix+"_"+cGenericAtlasSourceType 									
		sQualifiedName = (e_loop_var['qualifiedNamePart'])+"@"+cAtlasTypeSource					 	#cTypePrefix suffixed
		
		logger.info('Starting JSON generation for: '+pInFunc+ ' ' +sName)	
		
		
		sOutInsFileNameSource = cSourceJSONDir+"INS_"+vFilePrefixTime+"_bdpMetadata_"+pInFunc+"_"+sQualifiedName+cJsonExtension
		sOutDelFileNameSource = cSourceJSONDir+"DEL_"+vFilePrefixTime+"_bdpMetadata_"+pInFunc+cTextFileExt
		
		if sAction == "ADD":

			sJSONTextSource = '''{
		"referredEntities":{},
		"entity": {
			"guid": "-1",
			"status": "ACTIVE",
			"createdBy": null,
			"updatedBy": null,
			"createTime": null,
			"updateTime": null,
			"version": 1,
			"relationshipAttributes": {},
			"classifications": [],
			"typeName": "'''+cAtlasTypeSource+'''",
			"attributes": {
			  "qualifiedName":"'''+sQualifiedName+'''",
			  "name":"'''+sName+'''",
			  "description":"'''+sDescription+'''",
			  "owner":"'''+sOwner+'''",
			  "abbreviation":"'''+sAbbreviation+'''"
			}
		}
	}'''

			outFile = open(sOutInsFileNameSource,"w")
			outFile.write(sJSONTextSource)
		
		elif sAction == "DELETE":
			logger.info('Creating metadata delete file for : '+pInFunc+ ' ' +sName)
			vCounter += 1
			sJSONSource=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,sTypeName,"qualifiedName",sQualifiedName)
			sSourceGUID = bdpJSONParse.parseJsonDataLayer_1(sJSONSource,'entities',0,"guid")
			
			if vCounter == 1:
				sTempGUIDArray = "guid="+sSourceGUID
			else:
				sTempGUIDArray = "&guid="+sSourceGUID

			vFinalGUIDArray += sTempGUIDArray
		

		##############################
		#  HIVE DB CREATION PROCESS  #
		##############################
		logger.info('Starting hql file generation for: '+pInFunc+ ' ' +sName)	
		
		sRawDBPath = cRawHDFS + sName
		
		sHiveqlTextRawDB = "create database if not exists " +cRawHiveDB+ " location '" + sRawDBPath + "';"
		
		sHQLFinalFile = cAtlasHiveDir+cCreateDBFileName+"_"+vShortTimeFileName+cHQLFileExt
		# Append the Hive Queries to create  into a hql file.
		sCreateDBfile = open(sHQLFinalFile,"w")
		sCreateDBfile.write("\n"+sHiveqlTextRawDB+"\n")
		
	if "guid" in vFinalGUIDArray:
		sOutDelFileSource = open(sOutDelFileNameSource,"w")
		sOutDelFileSource.write(vFinalGUIDArray)
	
	logger.info('Successfully generated JSON and hql file for: '+pInFunc)	
	
	sDatasetFile.close()
	sys.exit(0)
	
###################################
#   Dataset json generation       # 
###################################

elif pInFunc == "dataset":
	
	file = open(cDatasetDriverFile,'rb')
	p = csv.DictReader(file)
		
	for loop_var in p:
		
		# Start reading each attribute and its corresponding values from the input csv
		sName = loop_var['name']
		sDescription = loop_var['description']
		sSOR = loop_var['sor']												
		sLoadRegion = loop_var['loadRegion']
		sSourceImageName = loop_var['sourceImageName']
		sHadoopStorage = loop_var['hadoopStorage']
		sType = loop_var['type']
		sffLayout = loop_var['ffLayout']
		sffHeaderLines = loop_var['ffHeaderLines']
		sffTrailerLines = loop_var['ffTrailerLines']
		sffDelimiterType = loop_var['ffDelimiterType']
		sffColDelimiter = loop_var['ffColDelimiter']
		sffTextQualifier = loop_var['ffTextQualifier']
		sffRowDelimiter = loop_var['ffRowDelimiter']
		sDBConnection = loop_var['dbConnection']
		sSchemaDefinition = loop_var['schemaDefinition']
		sGovDataDomain = loop_var['govDataDomain']
		sGovECDM = loop_var['govECDM']
		sLoadType = loop_var['loadType']
		sDeltaType = loop_var['deltaType']
		sPreviousLoadCompletion = loop_var['previousLoadCompletion']
		sNotification = loop_var['notification']
		sPartition = loop_var['partition']
		sPriority = loop_var['priority']
		sNeedLatestSnap = loop_var['needLatestSnap']
		sSORObjectName = loop_var['sorObjectName']
		sOwner = loop_var['owner']
		sAction = loop_var['action']
		
		sQualifiedName = loop_var['qualifiedNamePart']+"@"+cAtlasTypeDataset			#cTypePrefix suffixed
		sParentSourceQualifiedName = sSOR+"@"+cAtlasTypeSource
		
		logger.info('Starting JSON generation for: '+pInFunc+ ' ' +sName)	
		
		# entity output json file path and file name variables
		sOutInsFileNameDataset = cDatasetJSONDir+"INS_"+vFilePrefixTime+"_bdpMetadata_"+sQualifiedName+cJsonExtension
		sOutDelFileNameDataset = cDatasetJSONDir+"DEL_"+vFilePrefixTime+"_bdpMetadata_"+pInFunc+cTextFileExt
		
		logger.info('Outfile Name for : '+pInFunc+ ' ' +sOutInsFileNameDataset)	
			
		
		sJsonSource=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeSource,"qualifiedName",sParentSourceQualifiedName)
		sParentSourceGuid = bdpJSONParse.parseJsonDataLayer_1(sJsonSource,'entities',0,"guid")
		
		if sAction == "ADD":
			# entity json format follows
			sDatasetJsonText = '''{
		"referredEntities":{},
		"entity": {
			"guid": "-1",
			"status": "ACTIVE",
			"createdBy": null,
			"updatedBy": null,
			"createTime": null,
			"updateTime": null,
			"version": 1,
			"relationshipAttributes": {},
			"classifications": [],
			"typeName": "'''+cAtlasTypeDataset+'''",
			"attributes": {
				"qualifiedName": "'''+sQualifiedName+'''",
				"name": "'''+sName+'''",
				"description": "'''+sDescription+'''",
				"owner":"'''+sOwner+'''",
				"sor": {
					"guid":"'''+sParentSourceGuid+'''",
					"typeName": "'''+cAtlasTypeSource+'''"
				},
				"loadRegion":"'''+sLoadRegion+'''",
				"sourceImageName":"'''+sSourceImageName+'''",
				"hadoopStorage":"'''+sHadoopStorage+'''",
				"type": "'''+sType+'''",
				"ffLayout": "'''+sffLayout+'''",
				"ffHeaderLines": "'''+sffHeaderLines+'''",
				"ffTrailerLines": "'''+sffTrailerLines+'''",
				"ffDelimiterType": "'''+sffDelimiterType+'''",
				"ffColDelimiter": "'''+sffColDelimiter+'''",
				"ffTextQualifier": "'''+sffTextQualifier+'''",
				"ffRowDelimiter": "'''+sffRowDelimiter+'''",
				"dbConnection": "'''+sDBConnection+'''",
				"schemaDefinition": "'''+sSchemaDefinition+'''",
				"govDataDomain": "'''+sGovDataDomain+'''",
				"govECDM": "'''+sGovECDM+'''",
				"loadType": "'''+sLoadType+'''",
				"deltaType": "'''+sDeltaType+'''",
				"previousLoadCompletion": "'''+sPreviousLoadCompletion+'''",
				"notification": "'''+sNotification+'''",
				"partition": "'''+sPartition+'''",
				"priority": "'''+sPriority+'''",
				"needLatestSnap": "'''+sNeedLatestSnap+'''",
				"sorObjectName": "'''+sSORObjectName+'''"	
			}
		}
	}'''
			
			# Write it into the entity json output file
			sEntityOutFile = open(sOutInsFileNameDataset,"w")
			sEntityOutFile.write(sDatasetJsonText)

			##############################
			#  HDFS Landing PATH
			##############################
			
			# entity output hdfs landing path file path and file name variable preparation
			
			logger.info('creating HDFS Landing path for : '+pInFunc+ ' ' +sName)
			
			sJsonLandingFileName = cHDFSPathJSONDir+"INS_"+vFilePrefixTime+"_HDFSLandingPath_"+sQualifiedName+cJsonExtension
			
			sHDFSLandingDirTemp=cLandingHDFS+sSOR+"/"+sName
			sHDFSLandingDir=sHDFSLandingDirTemp.replace('/','\/')
			sHDFSQualPathStringLanding=(cNameNodeURI+sHDFSLandingDirTemp).replace('/','\/')
			sHDFSLandingJsonText='''{  
	   "referredEntities":{ },
	   "entity":{  
		  "typeName":"'''+cAtlasTypeHDFSPath+'''",
		  "attributes":{  
			 "owner":"'''+sOwner+'''",
			 "modifiedTime":"'''+vShortTime+'''",
			 "isFile":false,
			 "numberOfReplicas":0,
			 "qualifiedName":"'''+sHDFSQualPathStringLanding+'''",
			 "description":null,
			 "extendedAttributes":null,
			 "path":"'''+sHDFSQualPathStringLanding+'''",
			 "posixPermissions":null,
			 "createTime":"'''+vShortTime+'''",
			 "fileSize":0,
			 "clusterName":"'''+cClusterName+'''",
			 "name":"'''+sHDFSLandingDir+'''",
			 "isSymlink":false,
			 "group":null
		  },
		  "guid":"-11111111111111",
		  "status":"ACTIVE",
		  "createdBy":"admin",
		  "updatedBy":"admin",
		  "createTime":"'''+vShortTime+'''",
		  "updateTime":"'''+vShortTime+'''",
		  "version":0,
		  "classifications":[  
		  ]
	   }
	}'''
			# Write it into the hdfs Landing json output file
			hdfsLandOutFile = open(sJsonLandingFileName,"w")
			hdfsLandOutFile.write(sHDFSLandingJsonText)		

			##############################
			#  HDFS Raw PATH
			##############################
			
			# entity output SI HIST file path and file name variable preparation
			logger.info('creating Raw path for : '+pInFunc+ ' ' +sName)
			
			sJsonRawFileName = cHDFSPathJSONDir+"INS_"+vFilePrefixTime+"_HDFSRawPath_"+sQualifiedName+cJsonExtension
			
			sHDFSRawDirTemp=cRawHDFS+sSOR+"/"+sName
			sHDFSRawDir=sHDFSRawDirTemp.replace('/','\/')
			sHDFSQualPathStringRaw=(cNameNodeURI+sHDFSRawDirTemp).replace('/','\/')
			sRawJsonText = '''{  
	   "referredEntities":{ },
	   "entity":{  
		  "typeName":"'''+cAtlasTypeHDFSPath+'''",
		  "attributes":{  
			 "owner":"'''+sOwner+'''",
			 "modifiedTime":"'''+vShortTime+'''",
			 "isFile":false,
			 "numberOfReplicas":0,
			 "qualifiedName":"'''+sHDFSQualPathStringRaw+'''",
			 "description":null,
			 "extendedAttributes":null,
			 "path":"'''+sHDFSQualPathStringRaw+'''",
			 "posixPermissions":null,
			 "createTime":"'''+vShortTime+'''",
			 "fileSize":0,
			 "clusterName":"'''+cClusterName+'''",
			 "name":"'''+sHDFSRawDir+'''",
			 "isSymlink":false,
			 "group":null
		  },
		  "guid":"-11111111111111",
		  "status":"ACTIVE",
		  "createdBy":"admin",
		  "updatedBy":"admin",
		  "createTime":"'''+vShortTime+'''",
		  "updateTime":"'''+vShortTime+'''",
		  "version":0,
		  "classifications":[  
		  ]
	   }
	}'''	
			# Write it into the hdfs Raw json output file
			sRawOutFile = open(sJsonRawFileName,"w")
			sRawOutFile.write(sRawJsonText)
		
		elif sAction == "DELETE":
		
			logger.info('Creating metadata delete file for : '+pInFunc+ ' ' +sName)
			vCounter += 1
			sJsonSource=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeDataset,"qualifiedName",sQualifiedName)
			sSourceGUID = bdpJSONParse.parseJsonDataLayer_1(sJsonSource,'entities',0,"guid")
			
			if vCounter == 1:
				sTempGUIDArray = "guid="+sSourceGUID
			else:
				sTempGUIDArray = "&guid="+sSourceGUID
			vFinalGUIDArray += sTempGUIDArray
			
	
	if "guid" in vFinalGUIDArray:
		sOutDelFile = open(sOutDelFileNameDataset,"w")
		sOutDelFile.write(vFinalGUIDArray)
		
	file.close()
	sys.exit(0)

		
###################################
#   attribute
###################################
elif pInFunc == "attribute":

	file = open(cAttributeDriverFile,'rb')
	p = csv.DictReader(file, delimiter=',', quotechar = cQuoteChar)
	
	#Read each attribute and generate the required json
	for loop_var in p:
		sName = loop_var['name']
		sDescription = loop_var['description']
		sIngestionDataset = loop_var['ingestionDataset']
		sColumnOrder = loop_var['columnOrder']
		sFixedWidth = loop_var['fixedWidth']
		sType = loop_var['type']
		sFormat = loop_var['format']
		sIsPrimaryKey = loop_var['isPrimaryKey']
		sIsUnique = loop_var['isUnique']
		sIsOptional = loop_var['isOptional']
		sIsSensitive = loop_var['isSensitive']
		sIsTokenizedOutsideBDP = loop_var['isTokenizedOutsideBDP']
		sLoadColumn = loop_var['loadColumn']
		sGovBusGlossary = loop_var['govBusGlossary']	
		sOwner = loop_var['owner']
		sAction = loop_var['action']		
		sQualifiedName = sName+"@"+loop_var['qualifiedNamePart']+"@"+cAtlasTypeDataset+"@"+cAtlasTypeAttribute
		sParentDatasetQualifiedName = loop_var['qualifiedNamePart']+"@"+cAtlasTypeDataset
		
		sOutInsFileName = cAttributeOutJSONDir+"INS_"+vFilePrefixTime+"_bdpMetadata_"+sQualifiedName+cJsonExtension
		sOutDelFileName = cAttributeOutJSONDir+"DEL_"+vFilePrefixTime+"_bdpMetadata_"+pInFunc+cTextFileExt
		
		# Fetch the Parent Dataset GUID
		sJsonDataset=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeDataset,"qualifiedName",sParentDatasetQualifiedName)
		sParentDatasetGuid = bdpJSONParse.parseJsonDataLayer_1(sJsonDataset,'entities',0,"guid")
		
		if sAction == "ADD":
			sJsonText = '''{
	"referredEntities":{},
	"entity": {
		"guid": "-1",
		"status": "ACTIVE",
		"createdBy": null,
		"updatedBy": null,
		"createTime": null,
		"updateTime": null,
		"version": 1,
		"relationshipAttributes": {},
		"classifications": [],
		"typeName": "'''+cAtlasTypeAttribute+'''",
		"attributes": {
			"qualifiedName": "'''+sQualifiedName+'''",
			"name": "'''+sName+'''",
			"description": "'''+sDescription+'''",
			"owner":"'''+sOwner+'''",
			"ingestionDataset": {
				"guid":"'''+sParentDatasetGuid+'''",
				"typeName": "'''+cAtlasTypeDataset+'''"
			},
			"columnOrder": "'''+sColumnOrder+'''",
			"fixedWidth": "'''+sFixedWidth+'''",
			"type": "'''+sType+'''",
			"format": "'''+sFormat+'''",
			"isPrimaryKey": "'''+sIsPrimaryKey+'''",
			"isUnique": "'''+sIsUnique+'''",
			"isOptional": "'''+sIsOptional+'''",
			"isSensitive": "'''+sIsSensitive+'''",
			"isTokenizedOutsideBDP": "'''+sIsTokenizedOutsideBDP+'''",
			"loadColumn": "'''+sLoadColumn+'''",
			"govBusGlossary": "'''+sGovBusGlossary+'''"
		}
	}
	}'''
			
			
			sOutInsFile = open(sOutInsFileName,"w")
			sOutInsFile.write(sJsonText)
			
		elif sAction == "DELETE":
			vCounter += 1
			sJsonDataset=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeAttribute,"qualifiedName",sQualifiedName)
			sDatasetGUID = bdpJSONParse.parseJsonDataLayer_1(sJsonDataset,'entities',0,"guid")
			
			if vCounter == 1:
				sTempGUIDArray = "guid="+sDatasetGUID
			else:
				sTempGUIDArray = "&guid="+sDatasetGUID
			vFinalGUIDArray += sTempGUIDArray
	if "guid" in vFinalGUIDArray:
		sOutDelFile = open(sOutDelFileName,"w")
		sOutDelFile.write(vFinalGUIDArray)
	
	file.close()
	sys.exit(0)

###################################
#   rule
###################################
elif pInFunc == "rule":
	
	rfile = open(cRuleDriverFile,'rb')
	rp = csv.DictReader(rfile)
	
	
	for r_loop_var in rp:
	
		#Read each rule and generate the required json
		sName = r_loop_var['name']
		sDescription = r_loop_var['description']
		sIngestionDataset = r_loop_var['ingestionDataset']
		sType = r_loop_var['type']
		sLogic = r_loop_var['logic'].replace('\"','\\"')
		sOwner = r_loop_var['owner']
		sAction = r_loop_var['action']
		sParentDatasetQualifiedName = r_loop_var['qualifiedNamePart']+"@"+cAtlasTypeDataset
		sQualifiedName = sName+"@"+r_loop_var['qualifiedNamePart']+"@"+cAtlasTypeDataset+"@"+cAtlasTypeRule #cTypePrefix suffixed

		# Fetch the parent dataset GUID
		sJsonDataset=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeDataset,"qualifiedName",sParentDatasetQualifiedName)
		sParentDatasetGuid = bdpJSONParse.parseJsonDataLayer_1(sJsonDataset,'entities',0,"guid")

		sOutInsFileNameRule = cRuleJSONDir+"INS_"+vFilePrefixTime+"_bdpMetadata_"+sQualifiedName+cJsonExtension
		sOutDelFileNameRule = cRuleJSONDir+"DEL_"+vFilePrefixTime+"_bdpMetadata_"+pInFunc+cTextFileExt
		
		logger.info('Starting JSON creation process for : '+pInFunc+ ' ' +sName)
		
		if sAction  == "ADD":

			sJsonTextRule='''{  
	   "referredEntities":{  },
	   "entity":{  
		  "typeName":"'''+cAtlasTypeRule+'''",
		  "attributes":{  
			 "owner":"'''+sOwner+'''",
			 "qualifiedName":"'''+sQualifiedName+'''",
			 "ingestionDataset":{  
				"guid":"'''+sParentDatasetGuid+'''",
				"typeName":"'''+cAtlasTypeDataset+'''"
			 },
			 "name":"'''+sName+'''",
			 "description":"'''+sDescription+'''",
			 "logic":"'''+sLogic+'''",
			 "type":"'''+sType+'''"
		  },
		  "guid": "-1",
		  "status": "ACTIVE",
		  "createdBy": null,
		  "updatedBy": null,
		  "createTime": null,
		  "updateTime": null,
		  "version":0,
		  "classifications":[  

		  ]
	   }
	}'''
		
			outFile = open(sOutInsFileNameRule,"w")
			outFile.write(sJsonTextRule)
			outFile.close()
		elif sAction == "DELETE":
			logger.info('Creating metadata delete file for : '+pInFunc+ ' ' +sName)
			
			vCounter += 1
			sJsonRule=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeRule,"qualifiedName",sQualifiedName)
			sRuleGUID = bdpJSONParse.parseJsonDataLayer_1(sJsonRule,'entities',0,"guid")
			
			if vCounter == 1:
				sTempGUIDArray = "guid="+sRuleGUID
			else:
				sTempGUIDArray = "&guid="+sRuleGUID
			vFinalGUIDArray += sTempGUIDArray
	
	if "guid" in vFinalGUIDArray:
		sOutDelFile = open(sOutDelFileNameRule,"w")
		sOutDelFile.write(vFinalGUIDArray)
		sOutDelFile.close()
	
	rfile.close()
	sys.exit(0)

	
elif pInFunc == "process":

	############################################################################
	# Loop through each dataset to fetch the corresponding GUID from ATLAS     #
	############################################################################
	sDatasetFile = open(cDatasetDriverFile,'rb')
	ep = csv.DictReader(sDatasetFile)
	
	for e_loop_var in ep:
				
		# Read the each dataset entry
		sSOR = (e_loop_var['sor'])
		sName = (e_loop_var['name'])
		sOwner = (e_loop_var['owner'])
		
		sHDFSLandingDir=cLandingHDFS+sSOR+"/"+sName 
		sHDFSRawDir=cRawHDFS+sSOR+"/"+sName 			
		sParentDatasetQualifiedName = e_loop_var['qualifiedNamePart']+"@"+cAtlasTypeDataset			#cTypePrefix suffixed
		
		logger.info('Starting process generation for : '+pInFunc+ ' ' +sName)		

		# Fetch dataset, Landing, SIHist GUIDs		
		sJsonDataset=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeDataset,"qualifiedName",sParentDatasetQualifiedName)
		sJsonHDFSLanding=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeHDFSPath,"name",sHDFSLandingDir)
		sJsonHDFSRaw=bdpJSONParse.getAtlasJson(cAtlasDomain,cAtlasPort,cAtlasTypeHDFSPath,"name",sHDFSRawDir)
		
		
		sDatasetGuid = bdpJSONParse.parseJsonDataLayer_1(sJsonDataset,'entities',0,"guid")
		sLandingPathGuid = bdpJSONParse.parseJsonDataLayer_1(sJsonHDFSLanding,'entities',0,"guid")
		sRawPathGuid = bdpJSONParse.parseJsonDataLayer_1(sJsonHDFSRaw,'entities',0,"guid")

		# Prepare Process json path and filename
		
		sAtlasProcessS2Landing = cProcessJSONDir+"INS_"+vFilePrefixTime+"_BDPProcessS2Landing_"+sParentDatasetQualifiedName+cJsonExtension
		sAtlasProcessS2Raw = cProcessJSONDir+"INS_"+vFilePrefixTime+"_BDPProcessLanding2Raw_"+sParentDatasetQualifiedName+cJsonExtension
		sLandingProcessQualName = "bdpSrc2LandingIngestPrcss_"+sParentDatasetQualifiedName
		sRawProcessQualName = "bdpLanding2RawIngestPrcss_"+sParentDatasetQualifiedName
		
		sS2LandingJSONText='''{  
   "referredEntities":{  
   },
   "entity":{  
      "typeName":"'''+cAtlasTypeProcess+'''",
      "attributes":{
         "outputs":[  
            {  
               "guid":"'''+sLandingPathGuid+'''",
               "typeName":"'''+cAtlasTypeHDFSPath+'''"
            }
         ],
		 "queryGraph":null,
         "qualifiedName":"'''+sLandingProcessQualName+'''",
         "inputs":[  
            {  
               "guid":"'''+sDatasetGuid+'''",
               "typeName":"'''+cAtlasTypeDataset+'''"
            }
         ],
         "clusterName":"ibmbdp_sandbox_nonprod_5node",
         "name":"'''+sLandingProcessQualName+'''",
         "description":"hadoop ingestion",
         "startTime":"'''+vShortTime+'''",
         "operationType":"'''+sLandingProcessQualName+'''",
         "endTime":"'''+vShortTime+'''",
         "userName":"'''+sOwner+'''"
      },
      "guid":"-11111111111",
      "status":"ACTIVE",
      "createdBy":"'''+sOwner+'''",
      "updatedBy":"'''+sOwner+'''",
      "createTime":"'''+vShortTime+'''",
      "updateTime":"'''+vShortTime+'''",
      "version":0,
      "classifications":[  
      ]
   }
}'''
		
		# Write it into the Source to Landing Process json output file
		sProcessS2LandingFile = open(sAtlasProcessS2Landing,"w")
		sProcessS2LandingFile.write(sS2LandingJSONText)
		
		sS2RawJSONText='''{  
   "referredEntities":{  
   },
   "entity":{  
      "typeName":"'''+cAtlasTypeProcess+'''",
      "attributes":{  
         "owner":"'''+sOwner+'''",
         "outputs":[  
            {  
               "guid":"'''+sRawPathGuid+'''",
               "typeName":"'''+cAtlasTypeHDFSPath+'''"
            }
         ],
         "queryGraph":null,
         "qualifiedName":"'''+sRawProcessQualName+'''",
         "inputs":[  
            {  
               "guid":"'''+sLandingPathGuid+'''",
               "typeName":"'''+cAtlasTypeHDFSPath+'''"
            }
         ],
         "clusterName":"ibmbdp_sandbox_nonprod_5node",
         "name":"'''+sRawProcessQualName+'''",
         "description":"hadoop ingestion",
         "startTime":"'''+vShortTime+'''",
         "operationType":"'''+sRawProcessQualName+'''",
         "endTime":"'''+vShortTime+'''",
         "userName":"'''+sOwner+'''"
      },
      "guid":"-11111111111",
      "status":"ACTIVE",
      "createdBy":"'''+sOwner+'''",
      "updatedBy":"'''+sOwner+'''",
      "createTime":"'''+vShortTime+'''",
      "updateTime":"'''+vShortTime+'''",
      "version":0,
      "classifications":[  
      ]
   }
}'''
		
		# sS2RawJSONText='''{  
   # "referredEntities":{  
   # },
   # "entity":{  
      # "typeName":"'''+cAtlasTypeProcess+'''",
      # "attributes":{  
         # "owner":"'''+sOwner+'''",
         # "outputs":[  
            # {  
               # "guid":"'''+sRawPathGuid+'''",
               # "typeName":"'''+cAtlasTypeHDFSPath+'''"
            # }
         # ],
         # "queryGraph":null,
         # "qualifiedName":"'''+sRawProcessQualName+'''",
         # "inputs":[  
            # {  
               # "guid":"'''+sDatasetGuid+'''",
               # "typeName":"'''+sParentDatasetTypeName+'''"
            # }
         # ],
         # "clusterName":"ibmbdp_sandbox_nonprod_5node",
         # "name":"'''+sRawProcessQualName+'''",
         # "description":"hadoop ingestion",
         # "startTime":"'''+vShortTime+'''",
         # "operationType":"'''+sRawProcessQualName+'''",
         # "endTime":"'''+vShortTime+'''",
         # "userName":"'''+sOwner+'''"
      # },
      # "guid":"-11111111111",
      # "status":"ACTIVE",
      # "createdBy":"'''+sOwner+'''",
      # "updatedBy":"'''+sOwner+'''",
      # "createTime":"'''+vShortTime+'''",
      # "updateTime":"'''+vShortTime+'''",
      # "version":0,
      # "classifications":[  
      # ]
   # }
# }'''
		
		
		# Write it into the Source to SI Hist Process json output file
		sProcessS2RawFile = open(sAtlasProcessS2Raw,"w")
		sProcessS2RawFile.write(sS2RawJSONText)	
	sys.exit(0)
else:
	logger.error("ERROR: Python: Invalid input to python script generateAllMetadataJson.py")
	sys.exit(1)




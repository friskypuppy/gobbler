############################################################################################################################
# Script Name    : generateIMMMetadata.py
# Description    : This python script is responsible to POST opMetadata into Apache Atlas
# Author         : Cognizant Technology Solutions
############################################################################################################################

#=================================
# Import libraries
#=================================

import csv
import os
import sys
import time
import datetime
import logging
import subprocess
import bdpJSONParse
import shutil
import glob
import re
import inspect
import json

#=================================
# Import config File
#=================================


#sys.path.append('/home/cogetl-npr/dev01/ingestion_framework/config/')
#from bdpConfig import *
sys.path.append('/data/dev01/ingestion_framework/v2/config/')
from bdpConfig import *


#################
# Logging Info
###################

vTS = time.time()
vShortTime = datetime.datetime.fromtimestamp(vTS).strftime('%Y-%m-%dT%H:%M:%S.000Z')
vShortTimeFileName = datetime.datetime.fromtimestamp(vTS).strftime('%Y%m%d%H').replace('-','')
archiveFolderName = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')

# Check for Archive Folder or else create it
sFolderCheckFlag = os.path.isdir(cLogDir+archiveFolderName+"/bdpAtlas")
if sFolderCheckFlag == False:
	os.makedirs(cLogDir+archiveFolderName+"/bdpAtlas")
logfile = cLogDir+archiveFolderName+"/bdpAtlas/"+cLogFileIMM+"_"+vShortTimeFileName+".log"
logger = logging.getLogger(cLogFileIMM)
logger.setLevel(logging.DEBUG)
# create file handler which logs even debug messages
fh = logging.FileHandler(logfile)
fh.setLevel(logging.DEBUG)
# creating console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.ERROR)
# creating formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
fh.setFormatter(formatter)
# adding the handlers to logger
logger.addHandler(ch)
logger.addHandler(fh)


#=================================
# Variable Declaration and Assignment 
#=================================
pHierarchy = sys.argv[1]

sHierarchyUpper=pHierarchy.upper()
sOutFilePath = cIMMOutTempDir+'LOAD_BDP_'+sHierarchyUpper+'.csv'
sTempOutFilePath = cIMMOutTempDir+'TEMP_LOAD_BDP_'+sHierarchyUpper+'.csv'
outFile = open(sOutFilePath,"w")

sep = '"'+cCSVSep+'"'


#=================================
# System	
#=================================
if pHierarchy == "Systems" :
	logger.info('START: Generating IMM feeds for '+pHierarchy)
	sHeader = "Id,System_Name,infa_label,infa_description,businessName,Type,Description"
	
	line_1='"'+cIMMInstanceList[0]+sep+cIMMInstanceList[0]+sep+cIMMInstanceList[0]+sep+cIMMInstanceList[0]+sep+cIMMInstanceList[0]+sep+"BDP_SYSTEM"+sep+"File Data Provisioning Layer"+'"'
	line_2='"'+cIMMInstanceList[1]+sep+cIMMInstanceList[1]+sep+cIMMInstanceList[1]+sep+cIMMInstanceList[1]+sep+cIMMInstanceList[1]+sep+"BDP_SYSTEM"+sep+"DB Data Provisioning Layer"+'"'
	line_3='"'+cIMMInstanceList[2]+sep+cIMMInstanceList[2]+sep+cIMMInstanceList[2]+sep+cIMMInstanceList[2]+sep+cIMMInstanceList[2]+sep+"BDP_SYSTEM"+sep+"HDFS RAW Layer"+'"'
	line_4='"'+cIMMInstanceList[3]+sep+cIMMInstanceList[3]+sep+cIMMInstanceList[3]+sep+cIMMInstanceList[3]+sep+cIMMInstanceList[3]+sep+"BDP_SYSTEM"+sep+"HDFS INTEGRATED Layer"+'"'
	line_5='"'+cIMMInstanceList[4]+sep+cIMMInstanceList[4]+sep+cIMMInstanceList[4]+sep+cIMMInstanceList[4]+sep+cIMMInstanceList[4]+sep+"BDP_SYSTEM"+sep+"HIVE INTEGRATED Layer"+'"'
		
	outFile.write(sHeader+'\n')
	outFile.write(line_1+'\n')
	outFile.write(line_2+'\n')
	outFile.write(line_3+'\n')
	outFile.write(line_4+'\n')
	outFile.write(line_5+'\n')
	

	logger.info('END: Generating IMM feeds for '+pHierarchy)
#=================================
# Folders
#=================================
if pHierarchy == "Folders" :
	logger.info('START: Generating IMM feeds for '+pHierarchy)
	sHeader = "Id,Folder_Name,infa_label,infa_description,businessName,PARENT"
	line_1 = "BDP_CRT_EXT_TAB,BDP_CRT_EXT_TAB,BDP_CRT_EXT_TAB,BDP_CRT_EXT_TAB,BDP_CRT_EXT_TAB,"
	line_2 = "BDP_SRC2LANDING,BDP_SRC2LANDING,BDP_SRC2LANDING,BDP_SRC2LANDING,BDP_SRC2LANDING,"
	line_3 = "BDP_LANDING2RAW,BDP_LANDING2RAW,BDP_LANDING2RAW,BDP_LANDING2RAW,BDP_LANDING2RAW,"
	
	outFile.write(sHeader+'\n')
	outFile.write(line_1+'\n')
	outFile.write(line_2+'\n')
	outFile.write(line_3)
	
	logger.info('END: Generating IMM feeds for '+pHierarchy)
#=================================
# Mappings
#=================================

# New code for Mapping Starts
if pHierarchy == "Mappings" :
	logger.info('START: Generating IMM feeds for '+pHierarchy)
	sHeader = "Id,Mapping_Name,infa_description,infa_label,businessName,Business_Rules,Technical_Rules,mapping_file_name,PARENT"
	# Write the sHeader into the target file
	outFile.write(sHeader+'\n')
	# Loop 1: Read Folder File
	sfFolder = open(cFolderFileName,'rb')
	spFolder = csv.DictReader(sfFolder)

	for loop_folder in spFolder:
			sFolderParentName = (loop_folder['Id'])
						
			# Loop 2: Read Instance File
			fEntity = open(cEntityFileName,'rb')
			pEntity = csv.DictReader(fEntity)
			
			for loop_entity in pEntity:
				sEntityParentName = (loop_entity['Id'])
				 
				sId = sFolderParentName+"."+sEntityParentName
				sMappingName = sId
				infa_description = sId
				infa_label = sId
				businessName = sId
				Business_Rules = ""
				Technical_Rules = ""
				mapping_file_name = ""
				PARENT = sFolderParentName
				

				if sFolderParentName == "BDP_SRC2LANDING" and (sEntityParentName.find("DATA_PROV_DB") <> -1 or sEntityParentName.find("DATA_PROV_FILE") <> -1):
					finalMappingText = sId+sep+sMappingName+sep+infa_description+sep+infa_label+sep+businessName+sep+Business_Rules+sep+Technical_Rules+sep+mapping_file_name+sep+PARENT
					
					outFile.write('"'+finalMappingText+'"'+'\n')
				elif sFolderParentName == "BDP_LANDING2RAW" and (sEntityParentName.find("DATA_PROV_DB") <> -1 or sEntityParentName.find("DATA_PROV_FILE") <> -1):
					finalMappingText = sId+sep+sMappingName+sep+infa_description+sep+infa_label+sep+businessName+sep+Business_Rules+sep+Technical_Rules+sep+mapping_file_name+sep+PARENT
					
					outFile.write('"'+finalMappingText+'"'+'\n')
				elif sFolderParentName == "BDP_CRT_EXT_TAB" and (sEntityParentName.find("HDFS_RAW") <> -1):
					finalMappingText = sId+sep+sMappingName+sep+infa_description+sep+infa_label+sep+businessName+sep+Business_Rules+sep+Technical_Rules+sep+mapping_file_name+sep+PARENT
					outFile.write('"'+finalMappingText+'"'+'\n')
				#elif sFolderParentName == "BDP_CRT_EXT_TAB" and (sEntityParentName.find("HDFS_LANDING") <> -1):
					#finalMappingText = sId+sep+sMappingName+sep+infa_description+sep+infa_label+sep+businessName+sep+Business_Rules+sep+Technical_Rules+sep+mapping_file_name+sep+PARENT
					
					#outFile.write('"'+finalMappingText+'"'+'\n')



	logger.info('END: Generating IMM feeds for '+pHierarchy)
#=================================
# Instances
#=================================
if pHierarchy == "Instances" :

	logger.info('START: Generating IMM feeds for '+pHierarchy)
	
	tempOutFile = open(sTempOutFilePath,"w")
	#Fetch the list of all available datasets in atlasParseAttribute
	jsonAllDataset = bdpJSONParse.getAtlasJsonAllEntities(cAtlasDomain,cAtlasPort,cAtlasTypeDataset)	
	for i in jsonAllDataset["entities"]:
		x = json.dumps(i["guid"]).replace('"','')
		#jsonDataset = bdpJSONParse.getAtlasJsonAllDataset(cAtlasDomain,cAtlasPort,i["guid"])
		jsonDataset = bdpJSONParse.getAtlasJsonAllDataset(cAtlasDomain,cAtlasPort,x)
		sorGUID = json.dumps(jsonDataset["entity"]["attributes"]["sor"]["guid"]).replace('"','')
		datasetType = jsonDataset["entity"]["attributes"]["type"]
		jsonParentSource = bdpJSONParse.getAtlasJsonAllDataset(cAtlasDomain,cAtlasPort,sorGUID)
		sourceName = jsonParentSource["entity"]["attributes"]["name"]
		sourceDesc = jsonParentSource["entity"]["attributes"]["description"]
		sourceAbbreviation = jsonParentSource["entity"]["attributes"]["abbreviation"]
		
		 # dataset type defines the source type

		for line in cIMMInstanceList:
			if line.find("DATA_PROV_FILE") <> -1 and datasetType.upper() == "FILE":
				sId=line+"."+sourceName
				Instance_Name=sourceName
				infa_label=sourceName
				infa_description=sourceAbbreviation+"-"+sourceDesc
				businessName = sourceName
				PARENT = line
				Description = sourceAbbreviation+"-"+sourceDesc
				Type = "BDP_INSTANCE"
				
				inst_line = sId+sep+Instance_Name+sep+infa_label+sep+infa_description+sep+businessName+sep+PARENT+sep+Description+sep+Type
				tempOutFile.write('"'+inst_line+'"'+'\n')
				
			elif line.find("DATA_PROV_DB") <> -1 and datasetType.upper() == "DB":
				sId=line+"."+sourceName
				Instance_Name=sourceName
				infa_label=sourceName
				infa_description=sourceAbbreviation+"-"+sourceDesc
				businessName = sourceName
				PARENT = line
				Description = sourceAbbreviation+"-"+sourceDesc
				Type = "BDP_INSTANCE"
				
				inst_line = sId+sep+Instance_Name+sep+infa_label+sep+infa_description+sep+businessName+sep+PARENT+sep+Description+sep+Type
				tempOutFile.write('"'+inst_line+'"'+'\n')
				
			elif (line <> "DATA_PROV_FILE" and line <> "DATA_PROV_DB"):
				sId=line+"."+sourceName
				Instance_Name=sourceName
				infa_label=sourceName
				infa_description=sourceAbbreviation+"-"+sourceDesc
				businessName = sourceName
				PARENT = line
				Description = sourceAbbreviation+"-"+sourceDesc
				Type = "BDP_INSTANCE"
				
				inst_line = sId+sep+Instance_Name+sep+infa_label+sep+infa_description+sep+businessName+sep+PARENT+sep+Description+sep+Type
				tempOutFile.write('"'+inst_line+'"'+'\n')
				
	tempOutFile.close()
	
	#de duplicate the entries
	uniqlines = set(open(sTempOutFilePath).readlines())
	sHeader = "Id,Instance_Name,infa_label,infa_description,businessName,PARENT,Description,Type"
	outFile.write(sHeader+'\n')
	bar = outFile.writelines(set(uniqlines))
	outFile.close()
	
	logger.info('START: Generating IMM feeds for '+pHierarchy)
	
	
#--------------------------------
# Entities
#-------------------------------
## CREATE ENTITY FILE ##
		
elif pHierarchy == "Entities" :
	logger.info('START: Generating IMM feeds for '+pHierarchy)
	
	sHeader = "Id,Entity_Name,infa_label,businessName,PARENT,AI_ID,App_ID,App_Status,App_Type,App_Writeback,Business_Contact_Email,Business_Contact_Name,Business_Contact_Phone,Business_Owner_Name,Business_Unit,Calculation_Rules,Change_Frequency,Client_Technology,Connection_Method,Description,Document_Name,Editor_Email,Editor_Name,Grain_Type,History_Type,IT_Contact,Last_Signoff_Date,Next_Signoff_Date,Object_Parent,Profile_Completeness_Percentage,Publishing_Group,Retention,SignOff_Status,System_Owner_Name,Type,URL,infa_description,xPath"
	outFile.write(sHeader+'\n')
	
	
	sId = ""
	Entity_Name = ""
	infa_label = ""
	businessName = ""
	PARENT = ""
	AI_ID = ""
	App_ID = ""
	App_Status = ""
	App_Type = ""
	App_Writeback = ""
	Business_Contact_Email = ""
	Business_Contact_Name = ""
	Business_Contact_Phone = ""
	Business_Owner_Name = ""
	Business_Unit = ""
	Calculation_Rules = ""
	Change_Frequency = ""
	Client_Technology = ""
	Connection_Method = ""
	Description = ""
	Document_Name = ""
	Editor_Email = ""
	Editor_Name = ""
	Grain_Type = ""
	History_Type = ""
	IT_Contact = ""
	Last_Signoff_Date = ""
	Next_Signoff_Date = ""
	Object_Parent = ""
	Profile_Completeness_Percentage = ""
	Publishing_Group = ""
	Retention = ""
	SignOff_Status = ""
	System_Owner_Name = ""
	Type = ""
	URL = ""
	infa_description = ""
	xPath = ""
	
	# Fetch the list of all available datasets in atlastParseAttribute
	jsonAllDataset = bdpJSONParse.getAtlasJsonAllEntities(cAtlasDomain,cAtlasPort,cAtlasTypeDataset)	

	for i in jsonAllDataset["entities"]:
		sGUIDDatset = json.dumps(i["guid"]).replace('"','')
		jsonDataset = bdpJSONParse.getAtlasJsonAllDataset(cAtlasDomain,cAtlasPort,sGUIDDatset)
		sorGUID = json.dumps(jsonDataset["entity"]["attributes"]["sor"]["guid"]).replace('"','')
		datasetType = jsonDataset["entity"]["attributes"]["type"]
		datasetName = jsonDataset["entity"]["attributes"]["name"]
		
		jsonParentSource = bdpJSONParse.getAtlasJsonAllDataset(cAtlasDomain,cAtlasPort,sorGUID)
		sourceName = jsonParentSource["entity"]["attributes"]["name"]
		sourceDesc = jsonParentSource["entity"]["attributes"]["description"]
		sourceAbbreviation = jsonParentSource["entity"]["attributes"]["abbreviation"]
		
		f = open(cInstanceFileName,'rb')
		p = csv.DictReader(f)
		for loop_var in p: 
			par_id = (loop_var['Id'])
			Instance_Name = (loop_var['Instance_Name'])
			if Instance_Name == sourceName:
				sId = par_id+"."+datasetName
				Entity_Name = datasetName
				infa_label = datasetName
				PARENT  = par_id
				businessName = datasetName

				entity_line = sId+sep+Entity_Name+sep+infa_label+sep+businessName+sep+PARENT+sep+AI_ID+sep+App_ID+sep+App_Status+sep+App_Type+sep+App_Writeback+sep+Business_Contact_Email+sep+Business_Contact_Name+sep+Business_Contact_Phone+sep+Business_Owner_Name+sep+Business_Unit+sep+Calculation_Rules+sep+Change_Frequency+sep+Client_Technology+sep+Connection_Method+sep+Description+sep+Document_Name+sep+Editor_Email+sep+Editor_Name+sep+Grain_Type+sep+History_Type+sep+IT_Contact+sep+Last_Signoff_Date+sep+Next_Signoff_Date+sep+Object_Parent+sep+Profile_Completeness_Percentage+sep+Publishing_Group+sep+Retention+sep+SignOff_Status+sep+System_Owner_Name+sep+Type+sep+URL+sep+infa_description+sep+xPath
				outFile.write('"'+entity_line+'"'+'\n')
		
		f.close()

	logger.info('END: Generating IMM feeds for '+pHierarchy)
#--------------------------------
# Attribute
#-------------------------------
## CREATE ATTRIBUTE FILE ##
elif pHierarchy == "Attributes" :

	logger.info('START: Generating IMM feeds for '+pHierarchy)
	
	sHeader = "Id,Attribute_Name,Description,Type,infa_label,businessName,PARENT,Calculation_Rules,Parent,Owner,infa_description,XPATH,URL,Editor_Name,Editor_Email,App_ID,App_Status,Profile_Completeness,Signoff_Status,Last_Signoff_Date,Next_Signoff_Due,Business_Unit,App_Type,Business_Contact,Change_Frequency,IT_Contact,Connection_Method,App_Writeback,Client_Technology,Attribute_BG_term"
			
	outFile.write(sHeader+'\n')

	jsonAllAttribute = bdpJSONParse.getAtlasJsonAllEntities(cAtlasDomain,cAtlasPort,cAtlasTypeAttribute)	
	
	for i in jsonAllAttribute["entities"]:
		sGUIDDatset = json.dumps(i["guid"]).replace('"','')
		jsonAttribute = bdpJSONParse.getAtlasJsonAllDataset(cAtlasDomain,cAtlasPort,sGUIDDatset)
		ingestionDatasetGUID = json.dumps(jsonAttribute["entity"]["attributes"]["ingestionDataset"]["guid"]).replace('"','')
		attributeName = jsonAttribute["entity"]["attributes"]["name"]
		attributeDesc = jsonAttribute["entity"]["attributes"]["description"]
		attributeGovBusGlossary = jsonAttribute["entity"]["attributes"]["govBusGlossary"]
		
		jsonParentDataset = bdpJSONParse.getAtlasJsonAllDataset(cAtlasDomain,cAtlasPort,ingestionDatasetGUID)
		parentDatasetName = jsonParentDataset["entity"]["attributes"]["name"]
		
		f = open(cEntityFileName,'rb')
		p = csv.DictReader(f)
	
		for loop_entities in p:
			attr_par_id = (loop_entities['Id'])
			fileParentdatasetName = (loop_entities['Entity_Name'])
			
			
			if fileParentdatasetName == parentDatasetName:
				attr_id = attr_par_id+"."+attributeName
				attr_name = attributeName
				attr_desc = attributeDesc
				Attribute_BG_term = attributeGovBusGlossary
				infa_label = attributeName
				PARENT = attr_par_id
				Type = "ATTRIBUTE"
				businessName = ""
				Calculation_Rules = ""
				Parent = ""
				Owner = ""
				infa_description = ""
				XPATH = ""
				URL = ""
				Editor_Name = ""
				Editor_Email = ""
				App_ID = ""
				App_Status = ""
				Profile_Completeness = ""
				Signoff_Status = ""
				Last_Signoff_Date = ""
				Next_Signoff_Due = ""
				Business_Unit = ""
				App_Type = ""
				Business_Contact = ""
				Change_Frequency = ""
				IT_Contact = ""
				Connection_Method = ""
				App_Writeback = ""
				Client_Technology = ""
				Attribute_BG_term = ""
				
				line_val=attr_id+sep+attr_name+sep+attr_desc+sep+Type+sep+infa_label+sep+businessName+sep+PARENT+sep+Calculation_Rules+sep+Parent+sep+Owner+sep+infa_description+sep+XPATH+sep+URL+sep+Editor_Name+sep+Editor_Email+sep+App_ID+sep+App_Status+sep+Profile_Completeness+sep+Signoff_Status+sep+Last_Signoff_Date+sep+Next_Signoff_Due+sep+Business_Unit+sep+App_Type+sep+Business_Contact+sep+Change_Frequency+sep+IT_Contact+sep+Connection_Method+sep+App_Writeback+sep+Client_Technology+sep+Attribute_BG_term
				outFile.write('"'+line_val+'"'+'\n')
		f.close()

	logger.info('END: Generating IMM feeds for '+pHierarchy)
#--------------------------------
# Lineage
#-------------------------------
## CREATE LINEAGE FILE ##
		
elif pHierarchy == "Lineage" :

	logger.info('START: Generating IMM feeds for '+pHierarchy)
	
	sHeader = "sourcePath,destinationPath"
	outFile.write(sHeader+'\n')

	#------------------------------
	# Read the Attribute file and then draw the lineage information
	#------------------------------
	f = open(cAttributeFileName,'rb')
	p = csv.DictReader(f)

	for loop_instance in p:
		attr_str = (loop_instance['Id'])
		attr_BG_str = (loop_instance['Attribute_BG_term'])
		PAR_str = (loop_instance['PARENT'])
		attr_name_str = (PAR_str.replace('.','/'))
		attr = (loop_instance['Attribute_Name'])
		
		#----------------------------------
		# IMM Related path and directory
		#----------------------------------

		sIMM_BDP_SRC2RAW = cIMMAppBaseFolder+"BDP_SRC2LANDING"
		sIMM_BDP_RAW2INTEGRATED = cIMMAppBaseFolder+"BDP_LANDING2RAW"
		
		# BG Linkage to attribute in source
		if "DATA_PROV" in attr_str and len(attr_BG_str) > 0 and attr_BG_str.upper() <> "NA":
			if attr_str.find("DATA_PROV_FILE") <> -1:
				sBG_to_DP = attr_BG_str+sep+cIMMAppBaseFolder+attr_name_str+"/"+attr
			elif attr_str.find("DATA_PROV_DB") <> -1:
				sBG_to_DP = attr_BG_str+sep+cIMMAppBaseFolder+attr_name_str+"/"+attr
						
			outFile.write('"'+sBG_to_DP+'"'+'\n')

		if attr_str.find("DATA_PROV_FILE") <> -1:
			sREM_SRC_INFO = (PAR_str.replace('DATA_PROV_FILE.','')+'/'+attr).replace('.','/')
			sPRCSS_DP_to_LANDING = cIMMAppBaseFolder+attr_name_str+"/"+attr+sep+sIMM_BDP_SRC2RAW+"/BDP_SRC2LANDING."+PAR_str
			sSRC2LAND_PRCSS_to_LAND = sIMM_BDP_SRC2RAW+"/BDP_SRC2LANDING."+PAR_str+sep+cIMMAppBaseFolder+"HDFS_LANDING/"+sREM_SRC_INFO
			sLAND_2_RAW_PRCSS= cIMMAppBaseFolder+"HDFS_LANDING/"+sREM_SRC_INFO+sep+sIMM_BDP_RAW2INTEGRATED+"/BDP_LANDING2RAW."+(attr_name_str.replace('/','.'))
			sRAW_PRCSS_TO_RAW = sIMM_BDP_RAW2INTEGRATED+"/BDP_LANDING2RAW."+(attr_name_str.replace('/','.'))+sep+cIMMAppBaseFolder+"HDFS_RAW"+ attr_str.replace('DATA_PROV_FILE','').replace('.','/')    #((attr_str.replace('.','/')).replace('\/DATA_PROV_FILE',''))
		

			outFile.write('"'+sPRCSS_DP_to_LANDING+'"'+'\n')
			outFile.write('"'+sSRC2LAND_PRCSS_to_LAND+'"'+'\n')
			outFile.write('"'+sLAND_2_RAW_PRCSS+'"'+'\n')
			outFile.write('"'+sRAW_PRCSS_TO_RAW+'"'+'\n')
			
	
		if attr_str.find("DATA_PROV_DB") <> -1:
			sREM_SRC_INFO = (PAR_str.replace('DATA_PROV_DB.','')+'/'+attr).replace('.','/')
			sPRCSS_DP_to_LANDING = cIMMAppBaseFolder+attr_name_str+"/"+attr+sep+sIMM_BDP_SRC2RAW+"/BDP_SRC2LANDING."+PAR_str
			sSRC2LAND_PRCSS_to_LAND = sIMM_BDP_SRC2RAW+"/BDP_SRC2LANDING."+PAR_str+sep+cIMMAppBaseFolder+"HDFS_LANDING/"+sREM_SRC_INFO
			sLAND_2_RAW_PRCSS = cIMMAppBaseFolder+"HDFS_LANDING/"+sREM_SRC_INFO+sep+sIMM_BDP_RAW2INTEGRATED+"/BDP_LANDING2RAW."+(attr_name_str.replace('/','.'))
			sRAW_PRCSS_TO_RAW = sIMM_BDP_RAW2INTEGRATED+"/BDP_LANDING2RAW."+(attr_name_str.replace('/','.'))+sep+cIMMAppBaseFolder+"HDFS_RAW"+ attr_str.replace('DATA_PROV_DB','').replace('.','/')    #((attr_str.replace('.','/')).replace('\/DATA_PROV_FILE',''))
			
			outFile.write('"'+sPRCSS_DP_to_LANDING+'"'+'\n')
			outFile.write('"'+sSRC2LAND_PRCSS_to_LAND+'"'+'\n')
			outFile.write('"'+sLAND_2_RAW_PRCSS+'"'+'\n')
			outFile.write('"'+sRAW_PRCSS_TO_RAW+'"'+'\n')
					
		if attr_str.find("HDFS_RAW") <> -1:
			sREM_SRC_INFO = PAR_str.replace('.','/')
			sINTEG_TO_HIVE_PRCSS = cIMMAppBaseFolder+sREM_SRC_INFO+"/"+attr+sep+cIMMAppBaseFolder+"BDP_CRT_EXT_TAB/BDP_CRT_EXT_TAB."+(attr_name_str.replace('/','.'))
			sHIVE_PRCSS_INTEG_TO_HIVE_RAW = cIMMAppBaseFolder+"BDP_CRT_EXT_TAB/BDP_CRT_EXT_TAB."+(attr_name_str.replace('/','.'))+sep+(cIMMAppBaseFolder+attr_name_str+"/"+attr).replace('HDFS_RAW','HIVE_RAW')
			
			outFile.write('"'+sINTEG_TO_HIVE_PRCSS+'"'+'\n')
			outFile.write('"'+sHIVE_PRCSS_INTEG_TO_HIVE_RAW+'"'+'\n')		
	f.close()	
	logger.info('END: Generating IMM feeds for '+pHierarchy)


from pyspark.sql import SparkSession
from pyspark import SparkConf, SparkContext
from pyspark.sql import *
from pyspark.sql import HiveContext
from bdpConfig import *
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.types import StringType
from pyspark.sql.functions import unix_timestamp

def Validation(sType,sRunType,sClusterType,sLoadMode,TypeModedef,sTimeString):
                if sType=="file":
                        pass
                else:
                        print('This Spark job is supposed to run only  for Data Files')
                        exit(-1)

                if sRunType.lower()=="auto":
                        print('This Spark job is in AUTO Mode ')
                        pass

                if sClusterType.lower()=="operation":
                        print('This Spark job is for operations')
                        pass
                elif sClusterType.lower()=="datascience":
                        print('This Spark job is for datascience')
                        pass
                else:
                        print("Invalid cluster type ")
                        pass
                        exit(-1)

                if sLoadMode.lower() in TypeModedef:
                        print('LoadMode is %s'%sLoadMode)
                        pass
                else:
                        print('LoadMode can be on or off. Please check parameters.')
                        exit(-1)

                if len(sTimeString)==8:
                        pass
                else:
                        print("Invalid date")
                        exit(-1)


def SparkInit(appName_val):
                sparkSession = SparkSession.builder.appName(appName_val).enableHiveSupport().config("spark.serializer", "org.apache.spark.serializer.KryoSerializer").config("spark.logConf", "true").config("hive.exec.dynamic.partition", "true").config("hive.exec.dynamic.partition.mode", "nonstrict").getOrCreate()
                return sparkSession

def SparkCon(spark):
                ScContext= spark.sparkContext
                ScContext.setLogLevel("WARN")
                return ScContext

def check_table(dbName,tableName,spark):
                l=[]
                spark.sql("use "+dbName)
                l=spark.catalog.listTables()
                return len(filter(lambda x: x[0] ==tableName,l))

def loadCSVRdd(sDelimiter,sfileFormat,sPath,spark):
                rdd_d=spark.read.option('delimiter',sDelimiter).option('header',"false").format(sCSVfileFormat).load(sPath).rdd
                return rdd_d


def HeaderRdd(sHeaderCount,rdd):
                if sHeaderCount.strip()!="":
                        cnt=int(sHeaderCount)
                        header=rdd.take(cnt)
                        rdd_h=rdd.filter(lambda x : x not in header)
                else:
                        rdd_h=rdd
                return rdd_h

def Dataframe(sSchemaString,data_rdd,spark):
                fields = [StructField(field_name, StringType(), True) for field_name in sSchemaString.split("|")]
                schema = StructType(fields)
                df = spark.createDataFrame(data_rdd, schema).alias('df')
                return df

"""
def Tokenization(sSchemaString,sHash_column):
                schema_len=(len(sSchemaString.split("|")))
                cnt=0
                select_str=""
                select_str="df.select("
                for field_name in sSchemaString.split("|"):
                        if field_name in sHash_column:
                                cnt+=1
                                if cnt==schema_len:
                                        select_str+="md5(df."+field_name+").alias('"+field_name+"')"
                                else:
                                        select_str+="md5(df."+field_name+").alias('"+field_name+"'),"

                        else:
                                cnt+=1
                                if cnt==schema_len:
                                        select_str+="df."+field_name
                                else:
                                        select_str+="df."+field_name+","
                select_str+=")"
                return select_str
"""

def Tokenization(sSchemaString,sHash_column):
                schema_len=(len(sSchemaString.split("|")))
                cnt=0
                select_str=""
                select_str="spark.sql("+"\""+"select "
                for field_name in sSchemaString.split("|"):
                        if field_name in sHash_column:
                                cnt+=1
                                if cnt==schema_len:
                                        select_str+="encrypt_fpe_vae(concat('BDP-',"+field_name+"),'fpe_ff1_alphanumeric_profile') as '"+field_name+"'"
                                else:
                                        select_str+="encrypt_fpe_vae(concat('BDP-',"+field_name+"),'fpe_ff1_alphanumeric_profile') as "+field_name+","
                        else:
                                cnt+=1
                                if cnt==schema_len:
                                        select_str+=field_name
                                else:
                                        select_str+=field_name+","
                select_str+=" from temp_table "+"\""+")"
                return select_str


def SelectedCols(sLoadString,aliascol):
                loadColmn=""
                loadColmn=aliascol+".select("
                for col in sLoadString.split("|"):
                        loadColmn+=aliascol+"."+col+","
		return loadColmn


def CountDef(file_count,sRowCount):
                try:
                        print('Checking  Rows')
                        print(" Performing data count  validation ")
                        if int(file_count)==int(sRowCount):
                                print ("Count validated. Source file has %s records & landing has %s records"%(sRowCount,file_count))
                                print('Count validated. Source file has %s records & landing has %s records'%(sRowCount,file_count))
                        elif int(file_count)==0:
                                print ('File has no records. %s records found.'%(file_count))
                                exit(-1)
                        elif int(file_count)!=int(sRowCount):
                                print ("Validation Failed.Source file has %s records where as Datalanding has %s records. Process Halted for  Source Image."%(sRowCount,file_count))
                                print('Count validation Failed.Source file has %s records where as Datalanding has %s records.Process Halted for Source Image.'%(sRowCount,file_count))
                                exit(-1)
                except Exception as e:
                        print("Row Count validation failed.Halting Process")
                        exit(-1)

def InsertDef(sCast_str,sSource):
                vInsert_cmd=""
                vInsert_cmd+=" select "
                c=0
                while c < len(sCast_str.split("|"))-1:
                        vInsert_cmd+="cast ("+sCast_str.split("|")[c].split(" ")[0]+" as "+sCast_str.split("|")[c].split(" ")[1]+")"+","
                        c+=1
                else:
                        vInsert_cmd+="cast ("+sCast_str.split("|")[c].split(" ")[0]+" as "+sCast_str.split("|")[c].split(" ")[1]+")" +" from "+sSource
                        c+=1
                return vInsert_cmd


def AdditionalCol(sAdditionalDfCol,dfcol,start,sTimeStamp):
                for items in dfcol:
                        if items=="bdp_sor_extracttimestamp":
#                                sAdditionalDfCol+=".withColumn('"+items+"',lit(sTimeStamp))"
				sAdditionalDfCol+=".withColumn('"+items+"',unix_timestamp(lit('"+sTimeStamp+"'),'yyyyMMddHHmmss').cast('timestamp'))"
                        if items=="bdp_actiontype":
                                sAdditionalDfCol+=".withColumn('"+items+"',lit('"+"M"+"'))"
                        if items=="bdp_processcode":
                                sAdditionalDfCol+=".withColumn('"+items+"',lit('"+""+"'))"
                        if items=="bdp_processmessage":
                                sAdditionalDfCol+=".withColumn('"+items+"',lit('"+""+"'))"
                        if items=="bdp_createtimestamp":
				sAdditionalDfCol+=".withColumn('"+items+"',unix_timestamp(lit('"+start+"'),'yyyy-MM-dd HH:mm:ss').cast('timestamp'))"
#                                sAdditionalDfCol+=".withColumn('"+items+"',lit('"+start+"'))"
			if items=="bdp_rowstatus":
				sAdditionalDfCol+=".withColumn('"+items+"',lit('"+"A"+"'))"
			if items=="bdp_updatetimestamp":
#				sAdditionalDfCol+=".withColumn('"+items+"',lit('"+""+"'))"
				sAdditionalDfCol+=".withColumn('"+items+"',unix_timestamp(lit('""'),'yyyy-MM-dd HH:mm:ss').cast('timestamp'))"
                return sAdditionalDfCol


def SourceImageHistory(df_source,spark,sPartitionString,sMode,sDfComapareFlag,sSparkSIHmode,csourceImageHistoryPath,yy,mm,dd,sJoinCondition,sWhereConditionEntries,sWhereConditionDelete,sPartitionColumn):
                if sDfComapareFlag=="N":
                        if sMode=="Y":
                                df_so="df_source"+".write.partitionBy("+sPartitionString+").mode('"+sSparkSIHmode+"').orc('"+csourceImageHistoryPath+"')"
                                eval(df_so)
                        elif sMode=="N":
                                df_so="df_source"+".write.mode('"+sSparkSIHmode+"').orc('"+csourceImageHistoryPath+"')"
                                eval(df_so)
                elif sDfComapareFlag=="Y":
                        df1=df_source.alias('df1')
                        df2_str="select * from "+sRawdbName+"."+sSourceTable+" where "+sPartitionColumn+" in (select max(distinct "+sPartitionColumn+" ) from  "+sRawdbName+"."+sSourceTable+")"
                        df2=spark.sql(df2_str).alias('df2')
                        #TODO
                        JOIN_CONDITION=eval(sJoinCondition)
#                       sWhereConditionEntries=(df2.c_bank_det_id).isNull()&(df2.c_id).isNull()
                        sWhereConditionEntries=eval(sWhereConditionEntries)
                        sWhereConditionDelete=eval(sWhereConditionDelete)
                        #Deleted
                        df4=df2.join(df1,JOIN_CONDITION,'LEFTOUTER').where(sWhereConditionDelete).select('df2.*')
                        if len(sPartitionString.split(","))==3:
                                df4=df4.withColumn('bdp_actiontype',lit('D')).withColumn('year',lit(yy)).withColumn('month',lit(mm)).withColumn('dd',lit(dd))
                        elif len(sPartitionString.split(","))==2:
                                df4=df4.withColumn('bdp_actiontype',lit('D')).withColumn('year',lit(yy)).withColumn('month',lit(mm))
                        elif len(sPartitionString.split(","))==1:
                                df4=df4.withColumn('bdp_actiontype',lit('D')).withColumn('year',lit(yy))

                        #New Entries
                        df3=df1.join(df2,JOIN_CONDITION,'LEFTOUTER').where(sWhereConditionEntries).select('df1.*')
                        #Nochange Entries
                        df5=df1.join(df2,JOIN_CONDITION,'INNER').select('df1.*')
                        df_union=df3.union(df4).union(df5)
                        if sMode=="Y":
#                               df_so="df_union.write.format('orc').option('path','"+csourceImageHistoryPath+"').partitionBy("+sPartitionString+").mode('"+sSparkSIHmode+"')"
                                df_so="df_union"+".write.partitionBy("+sPartitionString+").mode('"+sSparkSIHmode+"').orc('"+csourceImageHistoryPath+"')"
                                eval(df_so)
                        elif sMode=="N":
                                df_so="df_union"+".write.mode('"+sSparkSIHmode+"').orc('"+csourceImageHistoryPath+"')"
                                eval(df_so)




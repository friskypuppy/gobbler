#==================================================
# Name        : jsonParse.py
# Description : Module contains all functions to
#               get operational metadata from Atlas
#               and parse as required.
#
# Author      : Cognizant Technology Solutions
#==================================================
import os
import requests
import json
import sys
from collections import OrderedDict
from cStringIO import StringIO
import pycurl

#--------------------------------
# Read from config
#--------------------------------

#sys.path.append('/home/cogetl-npr/dev01/ingestion_framework/config/')
#from bdpConfig import *
sys.path.append('/data/dev01/ingestion_framework/v2/config/')
from bdpConfig import *

#--------------------------------
# Functions
#--------------------------------

# Main Def for negotiate
def funcAtlasCurl(pActivity,pURL,pData):
	#vModLog = sLog + 'cmConnectInfo'
	#print vModLog + ' - In'
	sCurl = pycurl.Curl()
	sCurl.setopt(sCurl.HTTPAUTH, sCurl.HTTPAUTH_GSSNEGOTIATE)
	sCurl.setopt(sCurl.SSL_VERIFYPEER, False)
	sCurl.setopt(sCurl.USERPWD, ':')
	if pActivity == 'POST':
		sCurl.setopt(sCurl.HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json'])
		sStringIO = StringIO()
		sCurl.setopt(sCurl.URL, pURL)
		sCurl.setopt(sCurl.WRITEFUNCTION, sStringIO.write)
		sCurl.setopt(sCurl.CUSTOMREQUEST, "POST")
		sCurl.setopt(sCurl.POSTFIELDS, pData)
		sCurl.perform()
		sStringIO.close()
	elif pActivity == 'GET':
		sCurl.setopt(sCurl.HTTPHEADER, ['Accept: application/json'])
		sStringIO = StringIO()
		sCurl.setopt(sCurl.URL, pURL)
		sCurl.setopt(sCurl.WRITEFUNCTION, sStringIO.write)
		sCurl.perform()
		vOut = sStringIO.getvalue()
		sStringIO.close()
		return vOut

				
def getAtlasJson(pAtlasDomain,pAtlasPort,pTypeVal,pEntityColumn,pSource):
	sURL = "https://"+pAtlasDomain+":"+pAtlasPort+"/api/atlas/v2/search/dsl?typeName="+pTypeVal+"&query=where%20"+pEntityColumn+"%3D%22"+pSource+"%22"
	r=funcAtlasCurl("GET",sURL,"")
	return(json.loads(r,object_pairs_hook=OrderedDict));

	
# def deleteAtlasJson(pAtlasDomain,pAtlasPort,guidString):
	# sURL = "https://"+pAtlasDomain+":"+pAtlasPort+"/api/atlas/v2/entity/bulk/?"+guidString
	# print sURL
	# r=requests.delete(sURL, auth=(cAtlasUser,cAtlasPassword))
	
	# return(r);

def getAtlasJsonGuid(pAtlasDomain,pAtlasPort,guid):
	sURL = "https://"+pAtlasDomain+":"+pAtlasPort+"/api/atlas/entities/"+guid
	#r=requests.get(url, auth=(cAtlasUser,cAtlasPassword))
	r=funcAtlasCurl("GET",sURL,"")
	return(json.loads(r));
	
def getAtlasJsonGuidV2(pAtlasDomain,pAtlasPort,entityName):
	sURL = "https://"+pAtlasDomain+":"+pAtlasPort+"/api/atlas/v2/entity/"+entityName
	#r=requests.get(sURL, auth=(cAtlasUser,cAtlasPassword))
	r=funcAtlasCurl("GET",sURL,"")
	return(json.loads(r));
	

def getAtlasJsonAllDataset(pAtlasDomain,pAtlasPort,guid):
	sURL = "https://"+pAtlasDomain+":"+pAtlasPort+"/api/atlas/v2/entity/guid/"+guid
	#r=requests.get(sURL, auth=(cAtlasUser,cAtlasPassword))
	r=funcAtlasCurl("GET",sURL,"")
	return(json.loads(r));

def getAtlasJsonAllEntities(pAtlasDomain,pAtlasPort,pTypeVal):
	sURL = "https://"+pAtlasDomain+":"+pAtlasPort+"/api/atlas/v2/search/basic?excludeDeletedEntities=true&typeName="+pTypeVal
	#r=requests.get(sURL, auth=(cAtlasUser,cAtlasPassword))
	r=funcAtlasCurl("GET",sURL,"")
	return(json.loads(r));
	
def parseJsonDataLayer_1(pJsonData,pTag,pIndex,pTagVal1):
	return(pJsonData[pTag][pIndex][pTagVal1])


def parseJsonDataLayer_2(pJsonData,pTag,pIndex,pTagVal1,tagVal2):
	return(pJsonData[pTag][pIndex][pTagVal1][tagVal2])





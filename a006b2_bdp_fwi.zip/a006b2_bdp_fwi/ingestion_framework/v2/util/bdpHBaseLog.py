###### IMPORT ######
import sys
import pycurl
import json
from cStringIO import StringIO
from base64 import b64encode, b64decode

###### CONFIG VARIABLES ######
sys.path.append(sys.argv[10])
from bdpConfig import * 

###### COMMON MODULES ######
### Common module for setting CURL parameter ###
def connectInfo(pPassContent):
	vModLog = sLog + 'connectInfo'
	print vModLog + ' - In'
	vCurl = pycurl.Curl()
	vCurl.setopt(vCurl.HTTPAUTH, vCurl.HTTPAUTH_GSSNEGOTIATE)
	vCurl.setopt(vCurl.SSL_VERIFYPEER, False)
	vCurl.setopt(vCurl.USERPWD, ':')
	if pPassContent == 'y':
		vCurl.setopt(vCurl.HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json'])
	else:
		vCurl.setopt(vCurl.HTTPHEADER, ['Accept: application/json'])
	# If completed
	print vModLog + ' - Completed'
	return(vCurl)

### Common module for BASE64 ENcoded JSON data ###
def encodeInfo(pRowKey, pColVal):
	vModLog = sLog + 'encodeInfo'
	print vModLog + ' - In'
	if pRowKey:
		vData = '{"Row":[{"key":"' + b64encode(pRowKey) + '", "Cell": ['
	else:
		vData = ''
	# If completed
	for (i,j) in pColVal.iteritems():
		vData = vData + '{"column":"' + b64encode(i) +  '", "$":"' + b64encode(j) + '"},'
	# For completed
	print vModLog + ' - Completed'
	return(vData[:-1] + sEndRow)

### Common module for POST/PUT ###
def postInfo(pCurl, pURL, pData):
	vModLog = sLog + 'postInfo'
	print vModLog + ' - In'
	print vModLog + ' - URL - ' + pURL
	vStringIO = StringIO()
	pCurl.setopt(pCurl.URL, pURL)
	pCurl.setopt(pCurl.WRITEFUNCTION, vStringIO.write)
	pCurl.setopt(pCurl.CUSTOMREQUEST, "POST")
	pCurl.setopt(pCurl.POSTFIELDS, pData)
	pCurl.perform()
	print vModLog + ' ' + vStringIO.getvalue()
	vStringIO.close()
	print vModLog + ' - Completed'

###### Start Main Code ######

# Set vairables from config
sSnapRun = cHBaseNamespace + ':' + 'INGESTION_RUN_LOG'
sSnapLatest = cHBaseNamespace + ':' + 'INGESTION_RUN_SUMMARY'
# Set defaults
sEndRow = ']}]}'
sRowURL = 'fakerow'
sLog = 'LOG from bdpHBaseLog - '
# Get arguments
sSIName=sys.argv[1]
sDatasetName=sys.argv[2]
sExtractTimesTamp=sys.argv[3]
sHadoopType=sys.argv[4]
sObjectType=sys.argv[5]
sObjectName=sys.argv[6]
sLogLevel=sys.argv[7]
sLogStep=sys.argv[8]
sLogMessage=sys.argv[9]
# Setup Info for Post into Snap Run 
vURL = cHBaseURL + sSnapRun + '/' + sRowURL
vRowKey = sSIName + ':' + sDatasetName + ':' + sExtractTimesTamp
vColVal = {
    'TARGET:TYPE': sHadoopType,
    'TARGET:LAYER': 'raw',
    'TARGET:NAME': sSIName,
    'SOURCE:TYPE': sObjectType,
    'SOURCE:NAME': sObjectName,
    'SOURCE:EXTRACTTIMESTAMP': sExtractTimesTamp,
    'LOG:LEVEL': sLogLevel,
    'LOG:STEP': sLogStep,
    'LOG:MESSAGE': sLogMessage
}
vCurl = connectInfo('y')
postInfo(vCurl, vURL, encodeInfo(vRowKey, vColVal))
vCurl.close()
print sLog + 'Completed Snap Run'
# Setup Info for Post into Snap Run 
if sLogStep == 'END':
    # Get the last success extract timestamp
    vCurl = connectInfo('n')
    vStringIO = StringIO()
    vCurl.setopt(vCurl.URL, cHBaseURL + sSnapLatest + '/' + sSIName + ':' + sDatasetName + '*')
    print sLog + 'Get - ' + cHBaseURL + sSnapLatest + '/' + sSIName + ':' + sDatasetName + '*'
    vCurl.setopt(vCurl.WRITEFUNCTION, vStringIO.write)
    vCurl.perform()	
    print sLog + ' ' + vStringIO.getvalue()
    vPreviousValue = ''
    try:
        for i in json.loads(vStringIO.getvalue())['Row'][0]['Cell']: 
            if i['column'] == b64encode('INFO:LAST_SUCCESS_EXTRACTTIMESTAMP'):
                vPreviousValue = b64decode(i['$'])
            # If Completed
        # For Completed
    except Exception as e:
	print sLog + ' No Last Success Extract Timestamp'
    # Try Completed
    vStringIO.close()
    vCurl.close()
    # Post into summary
    vURL = cHBaseURL + sSnapLatest + '/' + sRowURL
    vRowKey = sSIName + ':' + sDatasetName
    vLastSuccessExtractTimestamp = sExtractTimesTamp if sLogLevel == 'SUCCESS' else vPreviousValue
    vColVal = {
        'TARGET:TYPE': sHadoopType,
        'TARGET:LAYER': 'raw',
        'TARGET:NAME': sSIName,
        'INFO:LAST_RUN_STATUS': sLogLevel,
        'INFO:LAST_SUCCESS_EXTRACTTIMESTAMP': vLastSuccessExtractTimestamp
    }
    vCurl = connectInfo('y')
    postInfo(vCurl, vURL, encodeInfo(vRowKey, vColVal))
    vCurl.close()
    print sLog + 'Completed Snap Summary'
else:
    pass
# If Completed

###### End Main Code ######

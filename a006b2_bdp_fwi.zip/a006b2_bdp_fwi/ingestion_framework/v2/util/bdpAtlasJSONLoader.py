############################################################################################################################
# Script Name    : bdpAtlasJsonLoader.py
# Description    : This python script is responsible to POST opMetadata into Apache Atlas
# Author         : Cognizant Technology Solutions
############################################################################################################################

#------------------------
# Import Libraries
#------------------------


import os, sys, glob
import requests, json
import time
import datetime
import logging
import pycurl
from cStringIO import StringIO

#------------------------
# Import Config
#------------------------
#sys.path.append('/home/cogetl-npr/dev01/ingestion_framework/config/')
#from bdpConfig import *
sys.path.append('/data/dev01/ingestion_framework/v2/config/')
from bdpConfig import *

vTS = time.time()
vShortTimeFileName = datetime.datetime.fromtimestamp(vTS).strftime('%Y%m%d%H').replace('-','')
sArchiveFolderName = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')


# Check for Archive Folder or else create it
sFolderCheckFlag = os.path.isdir(cLogDir+sArchiveFolderName+"/bdpAtlas/")
if sFolderCheckFlag == False:
	os.makedirs(cLogDir+sArchiveFolderName+"/bdpAtlas/")
logfile = cLogDir+sArchiveFolderName+"/bdpAtlas/"+cLogFileJsonLoader+"_"+vShortTimeFileName+".log"
logger = logging.getLogger(cLogFileJsonLoader)
logger.setLevel(logging.DEBUG)
# create file handler which logs even debug messages
fh = logging.FileHandler(logfile)
fh.setLevel(logging.DEBUG)
# creating console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.ERROR)
# creating formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
fh.setFormatter(formatter)
# adding the handlers to logger
logger.addHandler(ch)
logger.addHandler(fh)

def funcAtlasCurl(pActivity,pURL,pData):
	sCurl = pycurl.Curl()
	sCurl.setopt(sCurl.HTTPAUTH, sCurl.HTTPAUTH_GSSNEGOTIATE)
	sCurl.setopt(sCurl.SSL_VERIFYPEER, False)
	sCurl.setopt(sCurl.USERPWD, ':')
	if pActivity == 'POST':
		sCurl.setopt(sCurl.HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json'])
		sStringIO = StringIO()
		sCurl.setopt(sCurl.URL, pURL)
		sCurl.setopt(sCurl.WRITEFUNCTION, sStringIO.write)
		sCurl.setopt(sCurl.CUSTOMREQUEST, "POST")
		sCurl.setopt(sCurl.POSTFIELDS, pData)
		sCurl.perform()
		#sStringIO.getvalue()
		sStringIO.close()
	elif pActivity == 'GET':
		sCurl.setopt(sCurl.HTTPHEADER, ['Accept: application/json'])
		sStringIO = StringIO()
		sCurl.setopt(sCurl.URL, pURL)
		sCurl.setopt(sCurl.WRITEFUNCTION, sStringIO.write)
		sCurl.perform()
		vOut = sStringIO.getvalue()
		sStringIO.close()
		return vOut
		
#------------------------
# Configuration item fetched from config file
#------------------------

logger.info('*********************************************************************************************************************')
logger.info('                                         bdpAtlasJsonLoader.py  Starts')
logger.info('*********************************************************************************************************************')

sIngestionType=sys.argv[1]
sObjectType=sys.argv[2]

logger.info('=====================================')
logger.info('      I N P U T      P A R A M')
logger.info('=====================================')
logger.info('sIngestionType : '+sIngestionType)
logger.info('sObjectType    : '+sObjectType)
logger.info('=====================================')

#----------------------------------
# Ingestion of TYPE into Atlas
#----------------------------------
if sIngestionType == "type":
        sInFilePath = cAtlasTypeDir+sObjectType

        os.chdir(sInFilePath)
        for vLoopIngestionDataset in glob.glob("*.json"):
			sExtention = vLoopIngestionDataset.split('.')[-1]
			if sExtention == "json" :
				with open(vLoopIngestionDataset) as file :
						sCreateType=file.read()
						sCreateTypeJSON=json.loads(sCreateType)
						sData = json.dumps(sCreateTypeJSON)
						sURL = "https://"+cAtlasDomain+":"+cAtlasPort+"/api/atlas/types"
						#sPostTag=requests.post(sURL, headers={'Content-Type': 'application/json;  charset=UTF-8'}, data = json.dumps(sCreateTypeJSON), auth=(cAtlasUser ,cAtlasPassword))
						funcAtlasCurl("POST",sURL,sData)
			else:
					logger.error('*** ERROR : ingestion_dataset is not JSON type. IGNORE ...')
#----------------------------------
# Ingestion of ENTITY into Atlas
#----------------------------------
# V2 upload
if sIngestionType == "entity":
	sInFilePath=cAtlasEntityDir+sObjectType
	
	os.chdir(sInFilePath)
	for vLoopIngestionDataset in glob.glob("INS*.json"):
		
		extention = vLoopIngestionDataset.split('.')[-1]
		if extention == "json" :
			with open(vLoopIngestionDataset) as file :
				sCreateType=file.read()
				sCreateEntityJSON=json.loads(sCreateType)
				sData = json.dumps(sCreateEntityJSON)
				sURL = "https://"+cAtlasDomain+":"+cAtlasPort+"/api/atlas/v2/entity/"
				#old call#sPostTag=requests.post(sURL, headers={'Content-Type': 'application/json;  charset=UTF-8'}, data = json.dumps(sCreateEntityJSON), auth=(cAtlasUser ,cAtlasPassword))				
				funcAtlasCurl("POST",sURL,sData)
		else:
			logger.error('*** ERROR : ingestion_dataset is not JSON type. IGNORE ...')
# V1 upload
if sIngestionType == "entities":
	sInFilePath=cAtlasEntityDir+sObjectType
	
	os.chdir(sInFilePath)
	for vLoopIngestionDataset in glob.glob("INS*.json"):
		
		extention = vLoopIngestionDataset.split('.')[-1]
		if extention == "json" :
			with open(vLoopIngestionDataset) as file :
				sCreateType=file.read()
				sCreateEntityJSON=json.loads(sCreateType)
				sData = json.dumps(sCreateEntityJSON)
				sURL = "https://"+cAtlasDomain+":"+cAtlasPort+"/api/atlas/entities"
				#sPostTag=requests.post(sURL, headers={'Content-Type': 'application/json;  charset=UTF-8'}, data = json.dumps(sCreateEntityJSON), auth=:)				
				funcAtlasCurl("POST",sURL,sData)
		else:
			logger.error('*** ERROR : ingestion_dataset is not JSON type. IGNORE ...')				

logger.info('*********************************************************************************************************************')
logger.info('                                         bdpAtlasJsonLoader.py  Ends')
logger.info('*********************************************************************************************************************')



#Atlas
import requests
import json
from bdpConfig import *
import logging
from datetime import datetime, timedelta
import os
from decimal import *
import shutil
import  subprocess
from cStringIO import StringIO
import pycurl
#Atlas Defs

def funcAtlasCurl(pActivity,pURL,pData):
        #vModLog = sLog + 'cmConnectInfo'
        #print vModLog + ' - In'
        sCurl = pycurl.Curl()
        sCurl.setopt(sCurl.HTTPAUTH, sCurl.HTTPAUTH_GSSNEGOTIATE)
        sCurl.setopt(sCurl.SSL_VERIFYPEER, False)
        sCurl.setopt(sCurl.USERPWD, ':')
        if pActivity == 'POST':
                sCurl.setopt(sCurl.HTTPHEADER, ['Content-Type: application/json', 'Accept: application/json'])
                sStringIO = StringIO()
                sCurl.setopt(sCurl.URL, pURL)
                sCurl.setopt(sCurl.WRITEFUNCTION, sStringIO.write)
                sCurl.setopt(sCurl.CUSTOMREQUEST, "POST")
                sCurl.setopt(sCurl.POSTFIELDS, pData)
                sCurl.perform()
                sStringIO.close()
        elif pActivity == 'GET':
                sCurl.setopt(sCurl.HTTPHEADER, ['Accept: application/json'])
                sStringIO = StringIO()
                sCurl.setopt(sCurl.URL, pURL)
                sCurl.setopt(sCurl.WRITEFUNCTION, sStringIO.write)
                sCurl.perform()
                vOut = sStringIO.getvalue()
                sStringIO.close()
                return vOut


def atlas_search(cAtlasRuleSet,cAtlasEntitycolumnC,cSearchAttribute,Type):
        sURL = "https://"+cAtlasDomain+":"+cAtlasPort+"/api/atlas/v2/search/basic?excludeDeletedEntities=true&typeName="+cAtlasRuleSet+"&query=where%20"+cAtlasEntitycolumnC+"%20like%20%22*"+cSearchAttribute+"%22%20&%20type%3D%22"+Type+"%22"
	r=funcAtlasCurl("GET",sURL,"")
        return(json.loads(r));

def atlas_query(cAtlasAttribute,cAtlasEntitycolumnA,source):
        sURL = "https://"+cAtlasDomain+":"+cAtlasPort+"/api/atlas/v2/search/basic?excludeDeletedEntities=true&typeName="+cAtlasAttribute+"&query=where%20"+cAtlasEntitycolumnA+"%20like%20*"+source+"*"
	r=funcAtlasCurl("GET",sURL,"")
        return(json.loads(r));

def atlas_content(guid):
        sURL = "https://"+cAtlasDomain+":"+cAtlasPort+"/api/atlas/v2/entity/guid/"+guid
        #r=requests.get(url, auth=(cAtlasUser,cAtlasPassword))
	r=funcAtlasCurl("GET",sURL,"")
        return(json.loads(r));


def parseJsonDataLayer_1(jsonData,tag,index,tagVal1):
        return(jsonData[tag][index][tagVal1])

def guid_list(queriedData):
        index_guid=0
        guid_NameList=[]
        while index_guid <len(queriedData['entities']):
                guid_NameList.append(queriedData['entities'][index_guid]['guid'])
                index_guid+=1
        return guid_NameList



#Tokenized String Mapping

def typeMapping(hiveDDLCols,schemaString,tokenizeCols):
        c=0
        mappedCol=""
        for item in hiveDDLCols.split("|"):
                if c < len(schemaString.split("|"))-1:
                        c+=1
                        delmtr="|"
                else:
                        c+=1
                        delmtr=""
                if tokenizeCols in item:
                        a=item.split(" ")[0]
                        a+=" String"+str(delmtr)
                        mappedCol+=a
                else:
                        mappedCol+=item+str(delmtr)
        return mappedCol

#Logged setup

def log(sLogpath,sType,sSnap,dName):
        dat=datetime.now().strftime('%Y-%m-%d')
        #snap=datetime.now().strftime('%Y-%m-%d-%H_%M_%s')
        log_dir=sLogpath
        log_dir+=str(dat)+"/"+dName
        log_file=log_dir+"/"+sType+"_"+sSnap
        #Check Log Directory
        if (os.path.isdir(log_dir))==False:
                os.mkdir(log_dir)
        elif (os.path.isdir(log_dir))==True:
                pass
        return log_file

#Check date format

def TryCast(pValue, pType, pFormat):
    try:
        if pType:
            vValue = pType(pValue)
        else:
            for i in pFormat:
                try:
                    vValue = str(datetime.strptime(pValue, i).date())
                    break
                except (ValueError, TypeError):
                    vValue = None
    except (ValueError, TypeError):
        vValue = None
    return vValue

def sparkConfigParams(sFsize):
    sMbFileSize=Decimal(sFsize)/1024/1024
    if sMbFileSize < 50:
        pParm={"sExecutorCores":2,"sExecutorMemory":"4g","sDriverMemory":"1g","sDriverCores":1,"sNumExecutor":2}
    elif sMbFileSize < 200:
        pParm={"sExecutorCores":5,"sExecutorMemory":"8g","sDriverMemory":"1g","sDriverCores":1,"sNumExecutor":5}
    #TODO    
    return pParm


def sDataMove(sPath,sCtrlPath,sOutDir):
    if len(sPath)==0 or len(sCtrlPath)==0 or len(sOutDir)==0:
        exit(-1)
    else:
        try:
            shutil.move(sPath,sOutDir)
            shutil.move(sCtrlPath,sOutDir)
        except Exception as e:
            print(str(e))

def sHDFSMove(sFile,logger):
	try:
	    stamp=datetime.now().strftime("%Y%m%d%H%M%S")
            cmd="hadoop fs -mv "+sFile+"  "+sFile+"_"+stamp
            mvFlag=os.system(cmd)
	    if mvFlag==0:
		print("File Renamed Sucessfully in HDFS")	
		logger.warn("File Renamed Sucessfully in HDFS")
	    else:
                print("Failed to rename file in HDFS")
		logger.error("Failed to rename file in HDFS")
        except Exception as e:
            print(str(e))
	    logger.error(str(e))

def sHadoopCheckFile(dPath,logger):
	try:
		sCmd="hadoop fs -test -e "+dPath
		sCheckFlag=os.system(sCmd)
		if sCheckFlag==0:
			logger.warn("File exists. Calling for rename")
			try:
				sHDFSMove(dPath,logger)
			except Exception as e:
			        print(str(e))
			        logger.error(str(e))
		else:
			logger.info("File do not exits in HDFS. Processing new file.")
			pass
	except Exception as e:
            print(str(e))
	    logger.error(str(e))


def sHadoopPut(sPath,dPath,logger):
	copy_cmd="hadoop fs -put  "+sPath+" "+dPath
	cpFlag=os.system(copy_cmd)
        if cpFlag==0:
                print("File Copied Sucessfully to Landing zone.")
		logger.info("File Copied Sucessfully to Landing zone.")
        else:
                print("Job to copy data Landing zone failed.Halting Process")
		logger.error("Job to copy data Landing zone failed.Halting Process")
                exit(-1)

def sHdfsMkdir(cLandingHDFS,sSource,sSourceTable):
	dirCreateCmd="hadoop fs -mkdir -p "+cLandingHDFS+str(sSource)+"/"+str(sSourceTable)+"/"
        dirCreateFlag=os.system(dirCreateCmd)
	if dirCreateFlag==0:
		print("HDFS Directory for source created.")
        else:
	        print("Unable to create hdfs dir source. Check permission.Exiting since file cannot be copied.")
                exit(-1)

def checkSumValue(header,trailer,count,col_no,chksum,path,delimeter):
	if header==1:
	       headparm="|"+"sed '1d'"
	elif header>=2:
	       headparm="|"+"sed '1,"+str(header)+"d'"
	elif header==0:
	       headparm=""
	if trailer==1:
	       tailparam="|"+"sed '$d'"
	elif trailer >= 2:
	       count=(int(count))-(int(header))
	       v=count-trailer
	       tailparam="|"+"sed '1,"+str(v)+"!d'"
	elif trailer==0:
	       tailparam=""
	columnParam="| awk -F"+"\""+delimeter+"\""+" '{print $"+str(col_no)+"}'"
	chksum="| "+"md5sum"
	checkSumCmd="hadoop fs -cat "+path+" "+columnParam+headparm+tailparam+chksum
	process = subprocess.Popen(checkSumCmd, stdout=subprocess.PIPE, stderr=None, shell=True)
	output = process.communicate()
	val=str(output[0].strip().split(" ")[0].strip())
	return val

def ControlFileData(cCtrlPath,rowNum,colNum,sColDelimiter):
	file=open(cCtrlPath,'r')
	lines=file.readlines()
	value=lines[rowNum].strip().split(sColDelimiter)[colNum].strip()
	return value

def hiveCreateFunc(sMappedCol,cOpCol,sPartitionVal,cRawHiveDB,cRawHDFS,sLoadType,sSourceTable,logger):
        hiveDDLCol=""
        sAdditionalHiveCol=""
        c=0
        sHiveMode=""
        while c < len(sMappedCol.split("|"))-1:
                hiveDDLCol+=sMappedCol.split("|")[c].split(" ")[0]+"  "+sMappedCol.split("|")[c].split(" ")[1]+","
                c+=1
        else:
                hiveDDLCol+=sMappedCol.split("|")[c].split(" ")[0]+"  "+sMappedCol.split("|")[c].split(" ")[1]
                c+=1
        for items in cOpCol:
		if items in cOpTimeStampCol:
			sAdditionalHiveCol+=","+items+" "+"timestamp"
		else:
                	sAdditionalHiveCol+=","+items+" "+"String"
        if sPartitionVal=="day":
                sPartitionValString="'year','month','dd'"
                sPartitionValColumn="dd"
                sHivePartCol="year String,month String,dd String"
        elif sPartitionVal=="month":
                sPartitionValString="'year','month'"
                sPartitionValColumn="month"
                sHivePartCol="year String,month String"
        elif sPartitionVal=="year":
                sPartitionValString="'year'"
                sHivePartCol="year String"
                sPartitionValColumn="year"
        else:
                sPartitionValString="NA"
                sPartitionValColumn=""
        if sLoadType.lower()=="oneoff":
                logger.info('Load type for HIVE TABLE is Drop and Create')
                sHiveMode="drop table "+cRawHiveDB+"."+sSourceTable+";"
        elif sLoadType.lower()=="ongoing":
                logger.info('Load type for HIVE TABLE Append')
                sHiveMode=""
        if sPartitionValString=="NA":
                hive_create_cmd="hive -e '"+ sHiveMode+" create external table if not exists "+cRawHiveDB+"."+sSourceTable +"("+hiveDDLCol+sAdditionalHiveCol+")STORED AS ORC LOCATION "+"\""+cRawHDFS+"\""+";"+ "MSCK REPAIR TABLE "+cRawHiveDB+"."+sSourceTable +";"+"'"
        else:
                hive_create_cmd="hive -e '"+ sHiveMode+" create external table if not exists "+cRawHiveDB+"."+sSourceTable +"("+hiveDDLCol+sAdditionalHiveCol+") partitioned by("+sHivePartCol+")   STORED AS ORC LOCATION "+"\""+cRawHDFS+"\""+";"+ "MSCK REPAIR TABLE "+cRawHiveDB+"."+sSourceTable +";"+"'"
        return hive_create_cmd



def checkFileCount(jsonDataLogic,sCtrlPath,sHeaderCount,sTrailerCount,dPath,logger,sPath,sOutDir):
                sColDelimiter=jsonDataLogic["source"]["colDelimiter"]
                aRowNo=int(jsonDataLogic["source"]["aRowNo"])-1
                aColNo=int(jsonDataLogic["source"]["aColNo"])-1
                dataField=ControlFileData(sCtrlPath,aRowNo,aColNo,sColDelimiter).strip()
                command="hadoop fs -cat "+dPath+" | wc -l"
                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=None, shell=True)
                output = process.communicate()
                count=output[0].strip()
                svalidCount=int(count)-int(sHeaderCount)-int(sTrailerCount)
                if svalidCount==0:
                        logger.warn("Count is %s 'Zero'. Cannot Process file with empty rows."%(svalidCount))
			sDataMove(sPath,sCtrlPath,sOutDir)
                        exit(0)
                elif int(dataField)==int(svalidCount):
                        #print("Column count validated.File count is %s  and control file count is %s"%(svalidCount,dataField))
                        logger.info("Column count validated.File count is %s  and control file count is %s"%(svalidCount,dataField))
                else:
                        print("%s did not matched with the provided %s "%(svalidCount,dataField))
                        logger.error("%s did not matched with the provided %s "%(svalidCount,dataField))
                        exit(-1)
                return svalidCount


def checkSumFile(jsonDataLogic,sCtrlPath,chksum,logger,dPath,sHeaderCount,sTrailerCount):
                if jsonDataLogic["target"]["fullFile"]==True:
                        checksumCmd="hadoop fs -cat "+dPath+" | "+chksum
                        process = subprocess.Popen(checksumCmd, stdout=subprocess.PIPE, stderr=None, shell=True)
                        output = process.communicate()
                        checkSumval=str(output[0].strip().split(" ")[0].strip())
                        print (checkSumval)
                        sColDelimiter=jsonDataLogic["source"]["colDelimiter"]
                        aRowNo=int(jsonDataLogic["source"]["aRowNo"])-1
                        aColNo=int(jsonDataLogic["source"]["aColNo"])-1
                        #cCtrlPath=dPath # TODO as of now
                        dataField=ControlFileData(sCtrlPath,aRowNo,aColNo,sColDelimiter).strip()
                        if checkSumval==dataField:
                                logger.info("File Checksum Validated. given %s matched with %s"%(checkSumval,dataField))
                                #print("File Checksum Validated. given %s matched with %s"%(checkSumval,dataField))
                        else:
                                logger.error("CheckSum didnt match.Halting the process")
                                logger.error(" %s did not matched with the provided %s "%(checkSumval,dataField))
                                exit(-1)
                elif jsonDataLogic["target"]["fullFile"]==False:
                        command="hadoop fs -cat "+dPath+" | wc -l"
                        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=None, shell=True)
                        output = process.communicate()
                        count=output[0].strip()
                        sColDelimiter=jsonDataLogic["source"]["colDelimiter"]
                        aRowNo=int(jsonDataLogic["source"]["aRowNo"])-1
                        aColNo=int(jsonDataLogic["source"]["aColNo"])-1
                        try:
                                dataField=ControlFileData(sCtrlPath,aRowNo,aColNo,sColDelimiter).strip()
                        except Exception as e:
                                print(str(e))
                                logger.error("Unable fetch Control file data"+str(e))
                                exit(-1)
                        try:
                                checkSumval=checkSumValue(sHeaderCount,sTrailerCount,count,"1",chksum,dPath,sColDelimiter)
                        except Exception as e:
                                print(str(e))
                                logger.error("Unable get checksum data "+str(e))
                                exit(-1)

                        if checkSumval==dataField:
                                logger.info("Column Checksum Validated. given %s matched with %s"%(checkSumval,dataField))
                                #print("Column Checksum Validated. given %s matched with %s"%(checkSumval,dataField))
                        else:
                                logger.error("CheckSum didnt match.Halting the process")
                                logger.error(" %s did not matched with the provided %s "%(checkSumval,dataField))
                                exit(-1)


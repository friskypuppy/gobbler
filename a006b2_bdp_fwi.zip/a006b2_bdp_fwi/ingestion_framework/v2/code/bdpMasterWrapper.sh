#!/bin/bash
#source ../config/bdpConfig.sh
source /data/dev01/ingestion_framework/v2/config/bdpConfig.sh

sRun_type=${1}
sLoad_type=${2}
sDataset_type=${3}
sDataset_name=${4}
sCluster_type=${5}
sSource=${6}
sSource_table=${7}
sCurrent_extct_time=${8}
sObject_name=${9}
sObject_size=${10}
sLast_timestamp=${11}
sControl_file=${12}

log_dir=`date +"%F"`
sPath=$cLogDir""$log_dir"/$cLogBdpMasterWrapper/"
cFile=$cInboundDir$sSource"/pending/"$sObject_name
cCtrlFile=$cInboundDir$sSource"/pending/"$sControl_file
cErrorDir=$cInboundDir$sSource"/error/"

move()
{
mv $1 $2 
}

mkdir -p $sPath
sLog_file=`date +"%F_%H_%M_%s"`".log"
sLogpath=$sPath$sLog_file


echo "The number of arguments is: $#" &>> $sLogpath
a=${@}
echo "The total length of all arguments is: ${#a}: " &>> $sLogpath
count=0
for var in "$@"
do
    echo "The length of argument '$var' is: ${#var}" &>> $sLogpath
    (( count++ ))
    (( accum += ${#var} ))
done
echo "The counted number of arguments is: $count" &>> $sLogpath
echo "The accumulated length of all arguments is: $accum" &>> $sLogpath

if [ $count == 12 ];then
	echo "Valid number of arguments" &>> $sLogpath
else
	echo "Invalid number of arguments" &>> $sLogpath
	exit 1
fi

#echo "python $cPyScript $sRun_type $sLoad_type  $sDataset_type $sDataset_name  $sCluster_type  $sSource  $sSource_table  $sCurrent_extct_time  $sObject_name  $sObject_size  $sLast_timestamp $sControl_file $sLog_file $cConfigDir $cUtilDir &>> $sLogpath"

python  $cPyScript $sRun_type $sLoad_type  $sDataset_type $sDataset_name  $sCluster_type  $sSource  $sSource_table  $sCurrent_extct_time  $sObject_name  $sObject_size  $sLast_timestamp $sControl_file $sLog_file $cConfigDir $cUtilDir &>> $sLogpath


if [ $? -eq 0 ]; then
    echo "Ingestion Job Successfully Completed" &>> $sLogpath
else
    echo "Master Python Wrapper file execution failed.Ingestion Job Failed " &>> $sLogpath


move $cFile $cErrorDir 
if [ $? -eq 0 ]; then
    echo "$cFile moved to error dir" &>> $sLogpath
else
    echo "$cFile failed to move data to error" &>> $sLogpath
fi

move $cCtrlFile $cErrorDir 
if [ $? -eq 0 ]; then
    echo "$cCtrlFile moved to error dir" &>> $sLogpath
else
    echo "$cCtrlFile failed to move data to error" &>> $sLogpath
fi

echo $sLogpath
exit 1
fi

import requests
import json
import os
import sys
import operator
import logging
from datetime import datetime, timedelta
#import bdpCommon
from operator import itemgetter
import subprocess
#from bdpConfig import *
from os import path
#import datetime

if len(sys.argv)==16:
        pass
else:
        print ("Invalid no of input params. Halting job")
        exit(-1)


sConfigPath=sys.argv[14]
sUtilPath=sys.argv[15]

sys.path.append(sConfigPath)

from bdpConfig import *

sys.path.append(sUtilPath)

import bdpCommon


sSnap=sys.argv[13]
try:
	sLogFile=bdpCommon.log(cLogDir,cLogBdpMasterTriggerFile,sSnap,cLogBdpMasterTrigger)
except Exception as e:
        print(str(e))
        logger.error(" Error in setting up log path "+(str(e)))
        exit(-1)


#Local Logging
#print sLogFile
logger = logging.getLogger('masterTrigger')
hdlr = logging.FileHandler(sLogFile)
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
#logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.DEBUG)
hdlr.setFormatter(formatter)
logger.addHandler(hdlr)
logger.setLevel(logging.DEBUG)



###### CONFIGURATIONS
logger.info("Job Started")


sRunType=(sys.argv[1]).lower()
sLoadType=(sys.argv[2]).lower()
sDatasetType=(sys.argv[3]).lower()
sDatasetName=str((sys.argv[4]).strip().lower())
sClusterType=(sys.argv[5]).lower()
sSource=(sys.argv[6]).lower()
sSourceTable=(sys.argv[7]).lower()
sCurrentTimestamp=sys.argv[8].strip()
sObjectName=sys.argv[9]
sFileSize=int(sys.argv[10])
sLastTimestamp=sys.argv[11]
sObjectCtrlName=sys.argv[12]
sLogFileName=sys.argv[13]


try:
	if sRunType.strip()=="":
		logger.error("RunType cannot be blank")
		exit(-1)
	elif sLoadType.strip()=="":
		logger.error("LoadType cannot be blank")
		exit(-1)
	elif sDatasetType.strip()=="":
		logger.error("DatasetType cannot be blank")
		exit(-1)
	elif sDatasetName.strip()=="":
		logger.error("DatasetName cannot be blank")
		exit(-1)
	elif sClusterType.strip()=="":
		logger.error("ClusterType cannot be blank")
		exit(-1)
	elif sSource.strip()=="":
		logger.error("Source cannot be blank")
		exit(-1)
	elif sSourceTable.strip()=="":
		logger.error("SourceTable cannot be blank")
	        exit(-1)
	elif str(sCurrentTimestamp).strip()=="":
		logger.error("CurrentTimestamp cannot be blank")
		exit(-1)
	elif sObjectName.strip()=="":
		logger.error("sObjectName cannot be blank")
		exit(-1)
	elif str(sFileSize).strip()=="":
		logger.error("sFileSize cannot be blank")
		exit(-1)
	elif sLastTimestamp.strip()=="":
		logger.error("LastTimestamp cannot be blank")
		exit(-1)
except Exception as e:
        print(str(e))
        logger.error("Argument parsing error "+(str(e)))
        exit(-1)


#Initialize Parameters

sSpark_script=""
sTempCnt=0
sHiveDDLCols=""
sColName=""
sDataFormat=""
sSenstiveFlag="false"
sTokenFlag="false"
sTokenizeCols=""
sGenString=""
a=""
sDelmtr=""
sTok_Col=""
c=0
sMode=""
sSchemaString=""
sColDelimiter=""
sMappedCol=""
sActualColName=""
sLoadColFlag=""
sLoadMode=""
sPrimaryKey=""
sPrimaryKeyFlag=""
sTimeStamp=""
sTimeFlag=""
#cLogicalPart=cOpsLogicalDir+cLogicalPartSeparator
#sSiHistdbName=cLogicalPart+sSource+"_si_hist"
#sSourceTable=str(sSource)+"_"+sSourceTable
cRawHDFS+=str(sSource)+"/"+sSourceTable+"/"


#Check timestamp support

logger.info("Checking timestamp")

try:
	sTime=bdpCommon.TryCast(sCurrentTimestamp,None, cExtractTimestampFormat)
	if len(sTime)==10:
		logger.info(sTime)
		sTimeFlag=sTime
		sTimeStamp=sCurrentTimestamp
		if sTimeStamp==None or  sTimeStamp.strip()=="":
			logger.error("Invalid timestamp %s"%(sTimeStamp))
			exit(-1)
		else:
			logger.info(" valid timestamp %s"%(sTimeStamp))
	else:
		logger.error("Invalid Date returned %s"%(sTimeFlag))
                exit(-1)
	logger.info(sTimeFlag)
	if sTimeFlag!=None:
		logger.info("valid timestamp.Proceeding")
		if len(str(sTimeFlag))==10:
			sCurrentTimestamp=str(datetime.strptime(str(sTimeFlag), '%Y-%m-%d').strftime('%Y%m%d'))
			logger.info(" Casting timestamp to : %s"%(sCurrentTimestamp))
		else:
			logger.info("No timestamp casting required ")
			sCurrentTimestamp=str(sTimeFlag)
	elif sTimeFlag==None:
		logger.error("Invalid timestamp %s"%(sCurrentTimestamp))
		exit(-1)
except Exception as e:
        print(str(e))
	logger.error("Failed to cast %s"%(sCurrentTimestamp))
	exit(-1)

try:
	sHbaseString=sRunType+":"+sLoadType+":"+sDatasetType+":"+sDatasetName+":"+sClusterType+":"+sSource+":"+sSourceTable+":"+str(sCurrentTimestamp)+":"+sObjectName+":"+str(sFileSize)+":"+sLastTimestamp
except Exception as e:
        print(str(e))
        logger.error("Error to generate parameter string for spark")
        exit(-1)

#Check Mode of execution
logger.info("Check Mode of Execution")

if sDatasetType=="file":
        sSpark_script=cSparkFile
        sMode=" --master "+ cExecModeY+" --deploy-mode "+ cdeployModeCluster  +" "
        logger.info("Running Spark for File")
elif sDatasetType=="db":
        sSpark_script=cSparkFile
        sMode=" --master "+cExecModeY+" --deploy-mode "+cdeployModeClient +" "
        logger.info("Running Spark for DB")
else:
        logger.error("Invalid Ingestion type")
	logger.error(sDatasetType)
        exit(-1)


try:
        queryData=bdpCommon.atlas_query(cAtlasTypeAttribute,cAtlasEntitycolumnA,sDatasetName)
        logger.info("Loading atrribute data from Atlas")
except Exception as e:
        print(str(e))
	print cAtlasAttribute,cAtlasEntitycolumnA,sDatasetName
        logger.error("Attribute entry not available in atlas "+(str(e)))
        exit(-1)

try:
        jsonDataDataset=bdpCommon.atlas_query(cAtlasTypeDataset,cAtlasEntitycolumnB,sDatasetName)
        logger.info("Loading  Dataset data from Atlas")
except Exception as e:
        print(str(e))
        logger.error(str(e))
        exit(-1)

try:
	cSearchAttribute=sDatasetName+cAtlasQualifiedNameSeparator+sClusterType+cAtlasQualifiedNameSeparator+cAtlasTypeDataset+cAtlasQualifiedNameSeparator+cAtlasTypeRule
        RuleData=bdpCommon.atlas_search(cAtlasTypeRule,cAtlasEntitycolumnC,cSearchAttribute,cAtlasRuleDAType)
        logger.info("Loading Rule data from Atlas")
except Exception as e:
        print(str(e))
        logger.error("Rule entry not available in atlas "+(str(e)))
        exit(-1)


index=0
entity_NameList=[]
try:
        while index <len(queryData['entities']):
                entity_NameList.append(queryData['entities'][index]['attributes']['name'])
                index+=1
except Exception as e:
        print(str(e))
        logger.error("Dataset doest not exist "+str(e))
        print ("Dataset doest not exist "+str(e))
        exit(-1)

#Generating Schema String

i=1

for item in entity_NameList:
        if i==len(entity_NameList):
                sSchemaString+=item
                i+=1
        else:
                sSchemaString+=item+","
                i+=1


#Generating Guid List


index_guid=0
guid_NameList=[]

try:
        datasetGuid = bdpCommon.parseJsonDataLayer_1(jsonDataDataset,'entities',0,"guid")
	datasetGuid = json.dumps(datasetGuid).replace('"','') 
except Exception as e:
        print(str(e))
        logger.error("Data set parsing per guid error"+str(e))
        exit(-1)

#Only for dataset 

try:
        atlastParseDataset = bdpCommon.atlas_content(datasetGuid)
except Exception as e:
        print(str(e))
        logger.error("Data  parsing per guid error"+str(e))
        exit(-1)




#Extracting DATASET VALUES:
#print atlastParseDataset
for items in atlastParseDataset["entity"]["attributes"]:
	sColDelimiter = atlastParseDataset["entity"]["attributes"]["ffColDelimiter"]
	sLoadMode = atlastParseDataset["entity"]["attributes"]["loadType"]
	sHeaderCount=atlastParseDataset["entity"]["attributes"]["ffHeaderLines"]
	sTrailerCount=atlastParseDataset["entity"]["attributes"]["ffTrailerLines"]
	sPartitionVal=atlastParseDataset["entity"]["attributes"]["partition"]


countObj=len(queryData['entities'])

#Initializing Dictionaries

coldict={}
dataTypeDict={}


sTempCnt=0
while sTempCnt < countObj:
#	print queryData
        attributeGuid = bdpCommon.parseJsonDataLayer_1(queryData,'entities',sTempCnt,"guid")
	attributeGuid = json.dumps(attributeGuid).replace('"','')
        sTempCnt+=1
        atlastParseAttribute=bdpCommon.atlas_content(attributeGuid)


        sColName=""
        sDataFormat=""
        sSenstiveFlag="false"
        #-------------------------------------------
        # This is dynamic - Add any value for future
        #-------------------------------------------
        for items in atlastParseAttribute["entity"]["attributes"]:
		sColName=str(atlastParseAttribute["entity"]["attributes"]["name"])			
		colOrder=int(atlastParseAttribute["entity"]["attributes"]["columnOrder"])
		sDataFormat=str(atlastParseAttribute["entity"]["attributes"]["type"])
		sSenstiveFlag=atlastParseAttribute["entity"]["attributes"]["isSensitive"]
		sTokenFlag=atlastParseAttribute["entity"]["attributes"]["isTokenizedOutsideBDP"]
		sLoadColFlag=atlastParseAttribute["entity"]["attributes"]["loadColumn"]			
		sPrimaryKeyFlag=atlastParseAttribute["entity"]["attributes"]["isPrimaryKey"]

        #end of for items in atlastParseAttribute
        coldict[sColName]=colOrder
        dataTypeDict[sColName]=sDataFormat


        #List columns which need tokenization
        if sSenstiveFlag ==True and sTokenFlag ==False :
                sTokenizeCols=sTokenizeCols+sColName+","

	if sLoadColFlag==True:
		sActualColName+=sColName+","		

	if sPrimaryKeyFlag==True:
		sPrimaryKey+=sColName+","


#Applying Column Sorting and Mapping
try:
        sorted_col_dic = sorted(coldict.items(), key=operator.itemgetter(1))
        col_names=[str(x[0]) for x in sorted_col_dic]

        p=0
        sSchemaString=""
        sHiveDDLCols=""
	sLoadCols=""
        for item in col_names:
                if len(col_names)-1== p:
                        sSchemaString+=item
                else:
                        sSchemaString+=item+"|"
                p+=1

        p=0
        for item  in col_names:
		if item in sActualColName:
	        	sHiveDDLCols+=str(item)+" "
        	        sHiveDDLCols+=dataTypeDict[item]+"|"
		else:
			pass


	for item in col_names:
		if item in sActualColName:
			sLoadCols+=item+"|"
		else:
			pass
except Exception as e:
        print(str(e))
        logger.error("Column sorting failure "+str(e))
        exit(-1)



#Remove last value from string

sTokenizeCols=sTokenizeCols[:-1]

sLoadCols=sLoadCols[:-1]

sHiveDDLCols=sHiveDDLCols[:-1]

sPrimaryKey=sPrimaryKey[:-1]


# Making tokenized column as String Explictly


sMappedCol=bdpCommon.typeMapping(sHiveDDLCols,sLoadCols,sTokenizeCols)


logger.info("Column of tokenized fields mapped to string datatype explicitly.")


#Creating Spark command with parameters


#Move data to DataLanding Zone.
if sDatasetType=="file":

#path Setup
	sCtrlPath=cInboundDir+sSource+"/pending/"+str(sObjectCtrlName)
        sOutDir=cInboundDir+sSource+"/processed/"
        sErrorDir=cInboundDir+sSource+"/error/"
	sLandingPath=cLandingHDFS+str(sSource)+"/"+str(sSourceTable)+"/"
	sPath=cInboundDir+sSource+"/pending/"+str(sObjectName)
	dPath=cLandingHDFS+str(sSource)+"/"+str(sSourceTable)+"/"+str(sObjectName)
	sCtrlHdfs=cLandingHDFS+str(sSource)+"/"+str(sSourceTable)+"/"+str(sObjectCtrlName)
	
	if path.exists(sPath)==True:
		pass
	elif path.exists(sPath)==False:
		logger.error("Data File do not exist in pending dir.")
		exit(-1)

	if path.exists(sCtrlPath)==True:
                pass
        elif path.exists(sCtrlPath)==False:
                logger.error("Control File do not exist in pending dir.")
                exit(-1)


	dirHdfsCmd="hadoop fs -test -d "+cLandingHDFS+str(sSource)+"/"+str(sSourceTable)+"/"
	dirCmdFlag=os.system(dirHdfsCmd)
	if dirCmdFlag==0:
		logger.info("HDFS landing path exists")
	else:
		logger.info("Creating Directory")
		try:
			bdpCommon.sHdfsMkdir(cLandingHDFS,sSource,sSourceTable)
			logger.info("HDFS Directory for source created.")
		except Exception as e:
			print(str(e))
			logger.error("Unable to create hdfs dir source. Check permission.Exiting since file cannot be copied.")
			exit(-1)
	
	try:
		bdpCommon.sHadoopCheckFile(dPath,logger)
		logger.info("New Data file received. Proceeding with processing")
	except Exception as e:
                        print(str(e))
                        logger.error("Failed to check data file in hdfs")
	
	try:
                bdpCommon.sHadoopCheckFile(sCtrlHdfs,logger)
                logger.info("New Control file received. Proceeding with processing")
        except Exception as e:
                        print(str(e))
                        logger.error("Failed to check control file in hdfs")


	try:
		bdpCommon.sHadoopPut(sPath,dPath,logger)
		logger.info("File Copied Sucessfully to Landing zone.")
	except Exception as e:
	        print(str(e))
        	logger.error("File copy to landing zone failed "+str(e))
        	exit(-1)
		
#Path Setup
	
#	sCtrlPath=cInboundDir+sSource+"/pending/"+str(sObjectCtrlName)
#	sOutDir=cInboundDir+sSource+"/processed/"
#	sErrorDir=cInboundDir+sSource+"/error/"
#	print sCtrlPath
#	print sLandingPath

#Copy Control File

	try:
                bdpCommon.sHadoopPut(sCtrlPath,sLandingPath,logger)
                logger.info("Control File copied sucessfully to Landing zone.")
        except Exception as e:
                print(str(e))
                logger.error("Control File copy to landing zone failed "+str(e))
                exit(-1)


#MD5 check
		
	sTempCnt=0
	countRule=0
	try:
		countRule=len(RuleData['entities'])
	except Exception as e:
                print(str(e))
		logger.error("Unable to get count for attributes.Dataset not available.Check atlas")
		exit(-1)

	while sTempCnt < countRule:
		attributeGuid = bdpCommon.parseJsonDataLayer_1(RuleData,'entities',sTempCnt,"guid")
		attributeGuid = json.dumps(attributeGuid).replace('"','')
		sTempCnt+=1
		atlastParseAttribute=bdpCommon.atlas_content(attributeGuid)
		jsonDataLogic=json.loads(atlastParseAttribute["entity"]["attributes"]["logic"])
		if (jsonDataLogic["target"]["function"]).lower()=='md5':
			logger.info("Calling MD5 validation")
			try:
				bdpCommon.checkSumFile(jsonDataLogic,sCtrlPath,"md5sum",logger,dPath,sHeaderCount,sTrailerCount)
			except Exception as e:
                                print(str(e))
                                logger.error("Unable to validate checksum "+str(e))
                                exit(-1)	
		elif (jsonDataLogic["target"]["function"]).lower()=='count':
			logger.info("Calling Count Validation")
			#checkFileCount(jsonDataLogic,sCtrlPath)
			sRowCount=bdpCommon.checkFileCount(jsonDataLogic,sCtrlPath,sHeaderCount,sTrailerCount,dPath,logger,sPath,sOutDir)
		else:
			logger.info("Add More for logic Validation")

	

#Header Extract

#TODO

#Extract Trailer
	
	if sTrailerCount!=0:
		logger.info("Trailer present")
		#print ("Trailer present")
		command ="hadoop fs -cat "+dPath+" | tail -"+str(sTrailerCount)
		process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=None, shell=True)
		output = list(process.communicate())
		data=output[0].strip()
		sTrailerRows=[]
		for item in data.split("\r\n"):
		    sTrailerRows.append(item)
	else:
		logger.info("Skippping Trailer")
		sTrailerRows =[]
		data=""

####  Spark Config Params #

	sSparkParams=bdpCommon.sparkConfigParams(sFileSize)
	sExecutorCores=str(sSparkParams['sExecutorCores'])
	sExecutorMemory=str(sSparkParams['sExecutorMemory'])
	sDriverMemory=str(sSparkParams['sDriverMemory'])
	sDriverCores=str(sSparkParams['sDriverCores'])
	sNumExecutor=str(sSparkParams['sNumExecutor'])
	

if sDatasetType=="file":
        logger.info("Executing Spark for File")
	spark_cmd="spark-submit "+sMode+" --jars '"+cAtlasSparkJar+"'  --executor-cores "+sExecutorCores+" --executor-memory  "+sExecutorMemory+" --driver-memory  "+sDriverMemory+"  --driver-cores "+sDriverCores+"  --num-executors "+sNumExecutor+" --files "+cHiveXmlPath+" --py-files "+"\""+cPySparkConfig+"\""+" "+sSpark_script+" "+"\""+sHbaseString+"\""+" "+"\""+sSchemaString+"\""+" "+"\""+sColDelimiter+"\""+" "+"\""+sTokenizeCols+"\""+" "+"\""+sMappedCol+"\""+" "+"\""+sLoadCols+"\""+" "+"\""+data.strip()+"\""+" "+"\""+str(sHeaderCount)+"\""+" "+"\""+sPartitionVal+"\""+" "+"\""+sLoadMode.strip()+"\""+" "+"\""+sPrimaryKey+"\""+" "+"\""+str(sTrailerCount)+"\""+" "+"\""+str(sRowCount)+"\""+" "+"\""+sTimeStamp+"\""
else:
        logger.error("Invalid Ingestion type")
	print("Invalid Ingestion type")
        exit(-1)


logger.info('Triggering Spark Job')

spark_flag=0
cExportCmd+=spark_cmd

#print (cExportCmd)

try:
        spark_flag=os.system(cExportCmd)
except Exception as e:
        print(str(e))
        logger.error("Spark Execution failure "+str(e))
        exit(-1)
	
if spark_flag==0:
        logger.info('Spark job Executed Sucessfully')
	try:
		hCmd=bdpCommon.hiveCreateFunc(sMappedCol,cOpCol,sPartitionVal,cRawHiveDB,cRawHDFS,sLoadType,sSourceTable,logger)
		hiveFlag=os.system(hCmd)
	except Exception as e:
        	print(str(e))
        	logger.error("Hive Schema generation failure "+str(e))
	        exit(-1)

#	print (hCmd)
	if hiveFlag==0:
                print ("INFO:  HIVE TABLE CHECKED AND CREATED ! ! PARTITIONS UPDATED ")
		logger.info('HIVE TABLE CHECKED AND CREATED ! ! PARTITIONS UPDATED ')
		try:
			bdpCommon.sDataMove(sPath,sCtrlPath,sOutDir)
		except Exception as e:
		        print(str(e))
		        logger.error("Spark Execution failure "+str(e))
			logger.error("Failed to move file %s and %s "%(sPath,sCtrlPath))
			print ("Error: Failed to move file %s and %s "%(sPath,sCtrlPath))
		        exit(-1)
        else:
                print ("INFO:  FAILED TO CREATE HIVE TABLE. PLEASE CHECK ")
                logger.error('FAILED TO CREATE HIVE TABLE. PLEASE CHECK ')
		exit(-1)
else:
        logger.error(' Spark job Failed ')
	exit(-1)

logger.info("Job Completed")

from pyspark import SparkConf, SparkContext
from pyspark.sql import *
from pyspark.sql import HiveContext
import time
import datetime
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.types import StringType
from datetime import datetime
from datetime import datetime, timedelta
from pyspark.sql import SQLContext
#from __future__ import print_function
from pyspark.sql import SparkSession
import sys
import os
import json
import logging
from pyspark.sql.functions import unix_timestamp
#from bdpConfiguration_ingestion import *

from bdpConfig import *

import bdpSpark 


if __name__ == "__main__":

#Argument check
	print len(sys.argv)
	if len(sys.argv) !=15:
        	print("Usage: Spark_Argument_Error.Unexpected Number for arguments")
        	exit(-1)

#Variables

	sSparkSIHmode=""
	sTralier=""
	sPartition=""
	sMode=""
	sHivePartCol=""
	sAdditionalHiveCol=""
        sAdditionalDfCol=""
        sDfWithCol=""
	sDfComapareFlag=""
	sPrimaryKey=""
	sJoinCondition=""
	sWhereConditionEntries=""
	sWhereConditionDelete=""
#	cLogicalPart=cLogicalPartition+cLogicalPartSeparator
#	cLogicalPart=cOpsLogicalDir+cLogicalPartSeparator
	start = str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
	sPath=""

#Configurations
        
	startTime = datetime.utcnow()
        sSchemaString=str(sys.argv[2])
        sDelimiter=str(sys.argv[3])
        sHash_column=str(sys.argv[4])
        sHbaseString=sys.argv[1]
	sRunType=sHbaseString.split(':')[0]
	sLoadMode=sHbaseString.split(':')[1]
        sType=sHbaseString.split(':')[2] #DatasetType
	sDatasetName=sHbaseString.split(':')[3]
	sSourceTable=sHbaseString.split(':')[6]
	sClusterType=sHbaseString.split(':')[4]
        sSource=sHbaseString.split(':')[5]
        sTimeString=sHbaseString.split(':')[7]
        sFileName=sHbaseString.split(':')[8]
	sObjectSize=sHbaseString.split(':')[9]
	sLastTimestamp=sHbaseString.split(':')[10]
	sCast_str=str(sys.argv[5])
	sLoadString=str(sys.argv[6])
	sTralier=sys.argv[7]
	sHeaderCount=str(sys.argv[8])
	sPartition=(str(sys.argv[9])).lower()
	sLoadType=(str(sys.argv[10])).lower()
	sPrimaryKey=(str(sys.argv[11])).lower()
	sTrailerCount=int(sys.argv[12])
	sRowCount=int(sys.argv[13])
	sTimeStamp=str(sys.argv[14])
	sBlockSize=sHbaseString.split(':')[9]	
        cLandingHDFS+=str(sSource)+"/"+str(sSourceTable)+"/"
        cRawHDFS+=str(sSource)+"/"+sSourceTable+"/"
#	sRawdbName=cIntegratedHiveDB
#       sSiActdbName=cLogicalPart+sSource+sSource+"_si_active"
	sPath+=cLandingHDFS+str(sFileName)

	try:
		bdpSpark.Validation(sType,sRunType,sClusterType,sLoadMode,cLoadType,sTimeString)
	        print ("Variables validation done")
        except Exception as e:
                print(str(e))
                exit(-1)


	if sLoadType.lower()=="delta":
		if sLoadMode.lower()=="oneoff":
			sSparkSIHmode="Overwrite"
			sDfComapareFlag="N"
		if sLoadMode.lower()=="ongoing":
			sSparkSIHmode="Append"
			sDfComapareFlag="N"
	elif sLoadType.lower()=="full":
		if sLoadMode.lower()=="oneoff":
			sSparkSIHmode="Overwrite"
			sDfComapareFlag="N"
		if sLoadMode.lower()=="ongoing":
			sSparkSIHmode="Append"
			sDfComapareFlag="Y"
	else:
		print('Invalid load type')
		exit(-1)
	
	print('Load type for this job is %s'%(sSparkSIHmode))

	#Appname

	appName_val =str(sSource)+"_"+str(sSourceTable)
	
	#Partitions
	
	yyyy=sTimeString[:4]
	mm=sTimeString[4:6]
	day=sTimeString[6:8]

	#Spark Initialization


	try:
		spark=bdpSpark.SparkInit(appName_val)
	except Exception as e:
                print(str(e))
                exit(-1)
	
	try:
		sc=bdpSpark.SparkCon(spark)
	except Exception as e:
                print(str(e))
                exit(-1)

	try:
		spark.sql("create temporary function encrypt_fpe_vae as 'com.vormetric.hive.vae.EncryptFpe'")
	except Exception as e:
                print(str(e))
                exit(-1)
	
#Check table
#Executing Jobs
	print('Job Started')

#Check Tables
	
	if sDfComapareFlag=="Y":
		print('Checking Table exists or not ')
		if bdpSpark.check_table(cIntegratedHiveDB,sSourceTable,spark)==1:
			print ("Table exits for comparison")
			pass
		elif bdpSpark.check_table(cIntegratedHiveDB,sSourceTable,spark)==0:
			print ("Table does not exist for comparison. Please check the mode.Halting process")
			exit(-1)
	else:
		pass
	

	print("INFO:  Executing Spark's Data Landing job ")
	print('Removing Header and Trailer if found.')

	try:
		rdd=bdpSpark.loadCSVRdd(sDelimiter,sCSVfileFormat,sPath,spark)
	except Exception as e:
        	print(str(e))
	        exit(-1)


	try:
                rdd_1=bdpSpark.HeaderRdd(sHeaderCount,rdd)
	except Exception as e:
                print(str(e))
                exit(-1)
	

	tailers=""	
	if sTralier.strip()!="":
		tail=[]
		for i in sTralier.split("\n"):
			tail.append(i)
			tdd=sc.parallelize(tail)
			tdd1=tdd.map(lambda x: x.split(","))
			tdd2=tdd1.toDF()
			tailers=tdd2.take(sTrailerCount)
			data_rdd=rdd_1.filter(lambda x :  x not in tailers)
	else:
		data_rdd=rdd_1

	
	df=bdpSpark.Dataframe(sSchemaString,data_rdd,spark)
	df=df.alias('df')	
	df.persist()
	df.createOrReplaceTempView("temp_table")

	try:
		select_str=bdpSpark.Tokenization(sSchemaString,sHash_column)
	except Exception as e:
                print(str(e))
                exit(-1)

	df=eval(select_str)
	file_count=df.count()


#Choosing selected  colmns
	try:
		loadColmn=bdpSpark.SelectedCols(sLoadString,"df")
	except Exception as e:
                print(str(e))
                exit(-1)
	loadColmn=loadColmn[:-1]
	loadColmn+=")"
	
	df=eval(loadColmn)

#	df.write.mode("Overwrite").format("com.databricks.spark.avro").save(cHDFSLandingPath)

#Count Validation

	try:
                bdpSpark.CountDef(file_count,sRowCount)
        except Exception as e:
                print(str(e))
                exit(-1)

	df.persist()
	df.createOrReplaceTempView(sSource)

	

	
	print("In Memory  View created")
	
	print("Parsing hive columns")
	insert_cmd=""
	insert_cmd=bdpSpark.InsertDef(sCast_str,sSource)

	print('ATLAS METADATA DRIVEN :Casting values from Landing to Source Image')
	print('ATLAS METADATA DRIVEN :Writing data to the partitioned location in ORC Data Format')
	
	
	df_source=spark.sql(insert_cmd)

#SourceImageHistory Persistance as Table:


#IF drop Required

        if sLoadMode.lower()=="oneoff":
                print('Load type for TABLE is Overwrite')
		sAdditionalDfCol=bdpSpark.AdditionalCol(sAdditionalDfCol,cOpCol,start,sTimeStamp)
        elif sLoadMode.lower()=="ongoing":
                print('Load type for HIVE TABLE Append')
		sAdditionalDfCol=bdpSpark.AdditionalCol(sAdditionalDfCol,cOpCol,start,sTimeStamp)


	for i in sPrimaryKey.split(","):
		sJoinCondition+=" (df1."+i+"=="+"df2."+i+") &"
		sWhereConditionEntries+=" (df2."+i+").isNull() &"
		sWhereConditionDelete+=" (df1."+i+").isNull() &"

	sJoinCondition=sJoinCondition[:-1]
	sWhereConditionEntries=sWhereConditionEntries[:-1]
	sWhereConditionDelete=sWhereConditionDelete[:-1]
	
# Data Comparison	
	
	if sPartition=="day":
		sDfWithCol+="df_source"+sAdditionalDfCol+".withColumn('year',lit(yyyy)).withColumn('month',lit(mm)).withColumn('dd',lit(day))"
		df_source=eval(sDfWithCol)
		sPartitionString="'year','month','dd'"
		sPartitionColumn="dd"
                bdpSpark.SourceImageHistory(df_source,spark,sPartitionString,'Y',sDfComapareFlag,sSparkSIHmode,cRawHDFS,yyyy,mm,day,sJoinCondition,sWhereConditionEntries,sWhereConditionDelete,sPartitionColumn)
	elif sPartition=="month":
		sDfWithCol+="df_source"+sAdditionalDfCol+".withColumn('year',lit(yyyy)).withColumn('month',lit(mm))"
		df_source=eval(sDfWithCol)
		sPartitionString="'year','month'"
		sPartitionColumn="month"
                bdpSpark.SourceImageHistory(df_source,spark,sPartitionString,'Y',sDfComapareFlag,sSparkSIHmode,cRawHDFS,yyyy,mm,"",sJoinCondition,sWhereConditionEntries,sWhereConditionDelete,sPartitionColumn)
	elif sPartition=="year":
		sDfWithCol+="df_source"+sAdditionalDfCol+".withColumn('year',lit(yyyy))"
		df_source=eval(sDfWithCol)
                sPartitionString="'year'"
		sPartitionColumn="year"
		bdpSpark.SourceImageHistory(df_source,spark,sPartitionString,'Y',sDfComapareFlag,sSparkSIHmode,cRawHDFS,yyyy,"","",sJoinCondition,sWhereConditionEntries,sWhereConditionDelete,sPartitionColumn)
	else:
		sDfWithCol+="df_source"+sAdditionalDfCol
		df_source=eval(sDfWithCol)
		sPartitionString="NA"
		sPartitionColumn=""
                bdpSpark.SourceImageHistory(df_source,spark,sPartitionString,'N',sDfComapareFlag,sSparkSIHmode,cRawHDFS,"","","",sJoinCondition,sWhereConditionEntries,sWhereConditionDelete,sPartitionColumn)
	


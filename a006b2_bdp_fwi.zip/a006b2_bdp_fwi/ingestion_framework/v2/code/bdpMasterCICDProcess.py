#=============================================================================================
# Name		  	: masterCICDProcess.py
# Description 	: This is master shell script to drive the overall CICD process.
# Author		:	
# Create Date	:
# Revision History #
# Sl#		CR#			Date		Author			Desc
#
#==============================================================================================


##################################
#     Import Libraries 1
##################################

import csv
import os
import sys
import time
import datetime
import logging
import subprocess
import shutil
import glob
import re
import inspect

# Import the config file
sys.path.append('/data/dev01/ingestion_framework/v2/config/')
from bdpConfig import *



##################################
#     Logging Set up
##################################

vTS = time.time()
vShortTime = datetime.datetime.fromtimestamp(vTS).strftime('%Y-%m-%dT%H:%M:%S.000Z')
vShortTimeFileName = datetime.datetime.fromtimestamp(vTS).strftime('%Y%m%d%H').replace('-','')
sArchiveFolderName = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')

# Check for Archive Folder or else create it
sFolderCheckFlag = os.path.isdir(cLogDir+sArchiveFolderName+"/bdpAtlas/")
if sFolderCheckFlag == False:
	os.makedirs(cLogDir+sArchiveFolderName+"/bdpAtlas/")
logfile = cLogDir+sArchiveFolderName+"/bdpAtlas/"+cLogFileMasterCICD+"_"+vShortTimeFileName+".log"
logger = logging.getLogger(cLogFileMasterCICD)
logger.setLevel(logging.DEBUG)
# create file handler which logs even debug messages
fh = logging.FileHandler(logfile)
fh.setLevel(logging.DEBUG)
# creating console handler with a higher log level
ch = logging.StreamHandler()
ch.setLevel(logging.ERROR)
# creating formatter and add it to the handlers
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
fh.setFormatter(formatter)
# adding the handlers to logger
logger.addHandler(ch)
logger.addHandler(fh)



vNumbers = re.compile(r'(\d+)')
def defNumericalSort(pValue):
    sParts = vNumbers.split(pValue)
    sParts[1::2] = map(int, sParts[1::2])
    return sParts
		

#########################################################################################################
# ARCHIVAL FUNCTION : responsible to archive the json files generated as part of metadata upload process#
#########################################################################################################
	
def defArchive(pArchiveModule):
	sFolderName = datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d')
	sDestDir = cAtlasArchiveDir+"/"+pArchiveModule+"/"+sFolderName
	if pArchiveModule == "driver_files":
		sSrcDir = cMetadataDir
	else:
		sSrcDir = cAtlasEntityDir+"/"+pArchiveModule
	
	logger.info('################### ARCHIVAL MODULE INVOKED FOR ' + pArchiveModule + '  ###################\n')
	logger.info('#***************************************************************')
	logger.info('# Check for sub directory in case it is available or else create')
	logger.info('#***************************************************************')
	sFolderCheckFlag = os.path.isdir(sDestDir)
	if sFolderCheckFlag == False:
		logger.info('Creating Archive daily sub folders for ' + pArchiveModule)
		os.makedirs(sDestDir)
		logger.info('Archive daily sub folder'+sDestDir+' for ' + pArchiveModule +' created ')
		sFileExistSrc = os.listdir(sSrcDir) 
		if len(sFileExistSrc) > 0:
			for vLoopFileName in sFileExistSrc:
				logger.info(vLoopFileName)
				logger.info(sDestDir)
				logger.info('moving  Json Files from In directory ' + sSrcDir + ' to Archive folders for '+ pArchiveModule + ' with file name ' + vLoopFileName)
				sDestDir=cAtlasArchiveDir+"/"+pArchiveModule+"/"+sFolderName
				if pArchiveModule == 'imm':
					sAddTimeFileName = vShortTimeFileName+"_"+vLoopFileName
					logger.info('Copy/Move File Name Changed From: '+vLoopFileName+ 'To: '+sAddTimeFileName)
					shutil.copy(sSrcDir+"/"+vLoopFileName,sDestDir+"/"+sAddTimeFileName)
					logger.info('Moving File to IMM Outbound Directory: '+cIMMOutDir)
					shutil.copy(sSrcDir+"/"+vLoopFileName,cIMMOutDir+sAddTimeFileName)
				if pArchiveModule == 'driver_files':
					sAddTimeFileName = vShortTimeFileName+"_"+vLoopFileName
					logger.info('Copy/Move File Name Changed From: '+vLoopFileName+ 'To: '+sAddTimeFileName)
					shutil.copy(sSrcDir+"/"+vLoopFileName,sDestDir+"/"+sAddTimeFileName)
				else:
					shutil.move(sSrcDir+"/"+vLoopFileName,sDestDir+"/"+vLoopFileName)
		else:
			logger.warning('No File to copy in source folder '+sSrcDir)
	else:
		logger.info('Folder for Archival exists.'+ sDestDir)

		logger.info('#***************************************************************')
		logger.info('# Check for files to copy and then move it to archive directory.')
		logger.info('#***************************************************************')
		fileExistSrc = os.listdir(sSrcDir) 
		if len(fileExistSrc) > 0:
			for vLoopFileName in fileExistSrc:
				logger.info(sSrcDir+"/"+vLoopFileName)
				logger.info(vLoopFileName)
				logger.info(sDestDir)
				logger.info('MOVING Json Files from In directory ' + sSrcDir + ' to Archive folders for '+pArchiveModule + ' with file name ' + vLoopFileName)
				if pArchiveModule == 'imm':
					sAddTimeFileName = vShortTimeFileName+"_"+vLoopFileName
					logger.info('Copy/Move File Name Changed From: '+vLoopFileName+ 'To: '+sAddTimeFileName)
					shutil.copy(sSrcDir+"/"+vLoopFileName,sDestDir+"/"+sAddTimeFileName)
					logger.info('Moving File to IMM Outbound Directory: '+cIMMOutDir)
					shutil.copy(sSrcDir+"/"+vLoopFileName,cIMMOutDir+sAddTimeFileName)
				if pArchiveModule == 'driver_files':
					sAddTimeFileName = vShortTimeFileName+"_"+vLoopFileName
					logger.info('Copy/Move File Name Changed From: '+vLoopFileName+ 'To: '+sAddTimeFileName)
					shutil.copy(sSrcDir+"/"+vLoopFileName,sDestDir+"/"+sAddTimeFileName)
				else:
					shutil.move(sSrcDir+"/"+vLoopFileName,sDestDir+"/"+vLoopFileName)
		else:
			logger.warning('No File to copy in source folder '+sSrcDir)

##############################################################################################################
# GENERATE JSON : Generic module responsible to generate the json files required for metadata upload process #
# Generates JSON for all Atlas types based on the parameter passed into the function					     #
##############################################################################################################			
	
def defGenerateJson(pAtlasEntityType):
	sAction = 'generate JSON'
	sFuncName = inspect.stack()[0][3]
	logger.info('START: Starting '+sAction+' process using '+sFuncName)
	logger.info('Argument received for '+sFuncName+'-- sAction: '+sAction+', pAtlasEntityType: '+ pAtlasEntityType)
	
	if pAtlasEntityType in cAllowedMetadataTypes:	
		sPythonCommand='python '+cUtilDir+'bdpGenerateAllMetadataJSON.py '+str(pAtlasEntityType)
		sRetcode = os.system(sPythonCommand)
		if sRetcode == 0:
			logger.info(sAction+' process for ' + pAtlasEntityType + ' completed successfully.' )
			logger.info('END: Ending '+sAction+' process using '+sFuncName)
		else:
			logger.error(sAction+' process for ' + pAtlasEntityType + ' failed.' )
			logger.error('EXIT: Exit '+sAction+' process using '+sFuncName)
	else:
		logger.error('Invalid pAtlasEntityType Provided: '+pAtlasEntityType+'.Allowed atlasEntityType:source/dataset/attribute/rule' )
		logger.error('EXIT: Exit '+sAction+' process using '+sFuncName)
	
##########################################################################################################################
# DELETE JSON : Generic module responsible to delete any metadata uploaded into Atlas	based on the argument received.  #
##########################################################################################################################	

def defDeleteAtlasMetadata(pAction):
	sFuncName = inspect.stack()[0][3]
	logger.info('START: Starting '+pAction+' process for deleting Atlas Metadata using '+sFuncName)
	logger.info('Argument received for '+sFuncName+ '--- pAction: '+pAction)
	
	wipDir = cAtlasEntityDir+"/"+pAction
	os.chdir(wipDir)
	fileExistSrc = os.listdir(wipDir)
	if len(fileExistSrc) > 0:
		for infile in sorted(glob.glob('DEL*.txt'), key=defNumericalSort):
			guidString= open(infile,"r").read()
			logger.info('Working directory: '+wipDir+ '--- Filename: '+infile)
			retval=jsonParse.deleteAtlasJson(cAtlasDomain,cAtlasPort,guidString)
			
			if "200" in str(retval):
				logger.info('Deleting Atlas Metadata using '+sFuncName+' completed successfully for file '+infile)
				logger.info('END: Ending '+pAction+' process using '+sFuncName)
			else:
				logger.error('Deleting Atlas Metadata using '+sFuncName+' for file '+infile+' failed.')
				logger.error('EXIT: Exit '+pAction+' process using '+sFuncName)
	else: 
		logger.warning('No delete request for '+pAction+' process using '+sFuncName)
		logger.warning('Moving on to next entity using '+sFuncName)

##########################################################################################################################
# UPLOAD JSON : Generic module responsible to upload any metadata into Atlas based on the argument received.             #
##########################################################################################################################
		
	
def defAddAtlasMetadata(pAtlasEntityType):
	sAction = 'upload JSON'
	sFuncName = inspect.stack()[0][3]
	logger.info('START: Starting '+sAction+' process for '+pAtlasEntityType+' using '+sFuncName)
	logger.info('Argument received for '+sFuncName+ '--- sAction: '+sAction+", pAtlasEntityType: "+ pAtlasEntityType)
	if pAtlasEntityType in cAllowedMetadataTypes:	
		sPythonCommand = 'python '+cUtilDir+'/bdpAtlasJSONLoader.py entity ' + str(pAtlasEntityType)
		sRetcode = os.system(sPythonCommand)
		if sRetcode == 0:
			logger.info(sAction+' process for ' + pAtlasEntityType + ' completed successfully.' )
			if pAtlasEntityType == "source":
				logger.info('START: Starting hive database creation process for '+pAtlasEntityType+' using '+sFuncName)
				#sPythonCommand = 'hive -f '+ cHQLScriptDir + '/' +'createDB_*.hql'
				#sRetcode = os.system(sPythonCommand)
				sRetcode = 0 #Check the DB Creation strategy 
				if sRetcode == 0:
					#logger.info('Successfully created hive database for '+pAtlasEntityType+' using '+sFuncName)
					logger.info('Skipped hive database for '+pAtlasEntityType+' using '+sFuncName)
					logger.info('END: Ending hive database creation process using '+sFuncName)
					logger.info('END: Ending '+sAction+' process for '+pAtlasEntityType+' using '+sFuncName)
				else:
					logger.error(sAction+' process for ' + pAtlasEntityType +' failed.' )
					logger.error('EXIT: Exit '+sAction+' process using '+sFuncName)
			else:
				logger.info('Hive database creation process for '+pAtlasEntityType+' using '+sFuncName+' skipped.')	
		else:
			logger.error(sAction+' process for ' + pAtlasEntityType +' failed.')
			logger.error('EXIT: Exit '+sAction+' process using '+sFuncName)
	else:
		logger.error('Invalid pAtlasEntityType Provided: '+pAtlasEntityType+'. Expected: '+cAllowedMetadataTypes )
		logger.error('EXIT: Exit '+sAction+' process using '+sFuncName)
	
##########################################################################################################################
# GENERATE IMM FEEDS : Generic module responsible to generate IMM feeds for metadata exchange between ATLAS and IMM      #
##########################################################################################################################
		
def defGenerateAtlasToIMMMetadata(pAction):
	sFuncName = inspect.stack()[0][3]
	logger.info('START: Starting '+pAction+' process for imm metadata exchange.')
	logger.info('Argument received for '+sFuncName+'--- pAction: '+pAction+', cAtlasTypePrefix'+cAtlasTypePrefix)
	

	for vIMMObjectLoop in cIMMTypes:
		sPythonCommand='python '+cUtilDir+'bdpGenerateIMMMetadata.py '+str(vIMMObjectLoop)+' '+str(cAtlasTypePrefix)
		sRetcode=os.system(sPythonCommand)
		sRetcode=0
		if sRetcode == 0:
			logger.info('IMM metadata File for '+vIMMObjectLoop+' generated successfully.\n')
			logger.info('END: Ending '+pAction+' process for using '+sFuncName)
		else:
			logger.error('Error encountered while creating IMM Metadata Load Files for '+vIMMObjectLoop+'.\n')
			logger.error('EXIT: Exit '+pAction+' process using '+sFuncName+' while generationg '+vIMMObjectLoop+' metadata exchange process')

	
#############################################################################################################################################################
#   						 									MAIN MODULE    																		    	#
# There are 2 sections: AUTO and MANUAL. For Manual we need to pass the allowed metadata types like source, dataset, attribute etc. For auto just pass "auto"#
#############################################################################################################################################################

if len(sys.argv) == 2 and sys.argv[1] in cAllowedMetadataTypes:  
	pAtlasEntityType = sys.argv[1]
	logger.info('START: Inside manual Module for '+pAtlasEntityType)
	
	#Generic Calls
	defGenerateJson(pAtlasEntityType)
	defDeleteAtlasMetadata(pAtlasEntityType)
	defAddAtlasMetadata(pAtlasEntityType)

	#Specific Calls
	if pAtlasEntityType == 'source':
		defArchive("hive")
	if sys.argv[1] == 'dataset':
		defAddAtlasMetadata('hdfs_path')
		defArchive("hdfs_path")
	defArchive(pAtlasEntityType)
	defArchive('driver_files')
elif len(sys.argv) == 2 and sys.argv[1] == 'imm':
	pAtlasEntityType = sys.argv[1]

	defGenerateAtlasToIMMMetadata(pAtlasEntityType)
	defArchive(pAtlasEntityType)
	defArchive('driver_files')
	


elif len(sys.argv) == 2 and sys.argv[1] == 'auto':
	pAtlasEntityType = sys.argv[1]
	logger.info('START: Inside automated Module for '+pAtlasEntityType)
	for vAutoUploadSeq in cUploadSeqMetadataTypes:
		if vAutoUploadSeq <> 'imm':
			defGenerateJson(vAutoUploadSeq)
			defDeleteAtlasMetadata(vAutoUploadSeq)
			defAddAtlasMetadata(vAutoUploadSeq)
			if vAutoUploadSeq == 'source':
				defArchive("hive")
			if vAutoUploadSeq == 'dataset':
				defAddAtlasMetadata('hdfs_path')
				defArchive("hdfs_path")
		elif vAutoUploadSeq == 'imm':
			defGenerateAtlasToIMMMetadata(vAutoUploadSeq)
		defArchive(vAutoUploadSeq)
	defArchive('driver_files')
		
elif len(sys.argv) == 2 and sys.argv[1] == 'test':
	defArchive('driver_files')
	
else:
	logger.error('Encountered Error in Number Of Arguement provided to the script. Check the below sequence and command reference.\n')
	logger.error('########################################################################################################################')
	logger.error('*************************************************   GENERAL INFORMATION   *************************************************')
	logger.error(' Accepted arguement and sequence of executing them are : source,dataset,attribute,rule,process,imm')
	logger.error('Proveide arguement as auto to run CICD in one go')
	logger.error('########################################################################################################################\n\n')
	



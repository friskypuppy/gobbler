############################################################################################################################
# Script Name    : controlm_inbound.sh
# Description    : This shell script will be invoked by Control-M and will be responsible for triggering and specific BDP Job
# Author         : Cognizant Technology Solutions
############################################################################################################################

set -x
######################
# Initialize Config File	 
#####################
source /data/dev01/ingestion_framework/v2/config/bdpConfig.sh

# Log File Information
logFileName=$cLogFileName"_"`date +'%Y%m%d%H%M%S'`".log"
sControlMLogDir='bdpControlM'
sLogDirToday=`date +'%Y-%m-%d'`

# Log Folder Check and generation in case it is unavailable
if [ ! -d $cLogDir$sLogDirToday"/bdpControlM/" ]
then	
	mkdir -p $cLogDir$sLogDirToday"/bdpControlM/"
fi 	
sAbsLogFile=$cLogDir$sLogDirToday"/bdpControlM/"$logFileName

# Logging Function
func_Logger()
{
	echo -e "`date +'%Y%m%d%H%M%S'` - $1 - $2" >> $sAbsLogFile
}

# Copy/Move Function
func_move_file()
{
	mv -f $1 $2
	if [ $? == 0 ]
	then	
		func_Logger "INFO" "Inside func_move_file module  - File moved successfully from $1 to $2"	
	else
		func_Logger "ERROR" "Inside func_move_file module - File Move Failed from $1 to $2"
		func_Logger "ERROR" "Exiting file move module with exit code 1"
		func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
		exit -1
	fi	
}

# HBASE Logging Function
func_HBASE_Logger()
{
	if [ $# == 10 ]
	then	
		func_Logger "INFO" "Correct # of argument received for HBASE logging module."
		func_Logger "INFO" "START: HBASE logging Started for $7/$8......"
		echo $10
		python $cUtilDir"bdpHBaseLog.py" $1 $2 $3 $4 $5 $6 $7 $8 "$9" ${10}
		if [ $? == 0 ]
		then	
			func_Logger "INFO" "END: HBASE logging Completed for $7/$8..."	
		else
			func_Logger "ERROR" "Error in HBASE Logging for $7/$8"
			func_Logger "ERROR" "Exiting HBASE logging module with exit code 1"
			func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
			exit -1
		fi
	else
		func_Logger "ERROR" "Incorrect # of argument received for HBASE logging module."
		func_Logger "ERROR" "Exiting HBASE logging module with exit code 1"
		func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
		exit -1
	fi 
}


func_Logger 'INFO' '########## STARTING Control M wrapper Script ############'
func_Logger "INFO" "Log file name: $sAbsLogFile"

# Number of Argument Check
if [ $# -eq 5 ]
then
	func_Logger "INFO" "# of Argument Check - Number of argument provided is incorrect: $#"
else	
	func_Logger "ERROR" "Number of argument provided which is $# is incorrect."
	func_Logger "ERROR" "Exiting # of Argument Check module with exit code 1"
	func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
	exit -1
fi


# 1st Argument Check
if [ $1 == "DATAANDCTRLFILE" ]
then
	func_Logger "INFO" "1st Argument Check - LogicalDatasetType from Control-M: $1"
	sLogicalDatasetType=$1
else	
	func_Logger "ERROR" "LogicalDatasetType from Control-M: $1 is incorrect. Must be DATAANDCTRLFILE  or DATAFILE"
	func_Logger "ERROR" "Exiting 1st Argument Check module with exit code 1"
	func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
	exit -1
fi


# Rest of the Argument Check
if [ $1 == 'DATAANDCTRLFILE' ]
then
	if [ $# -eq 5 ]
	then
		func_Logger "INFO" "Inside Other argument check module  - correct Number of argument received from control M: $#"
		date -d $2 '+%Y%m%d' > /dev/null 2>&1
		if [ $? == 0 ]
		then	
			func_Logger "INFO" "Inside Other argument check module  - correct format of ODATE received from Control-M: $2"	
			if [ $5 == 'oneoff' -o $5 == 'ongoing' ]
			then	
				func_Logger "INFO" "Inside Other argument check module  - correct value of load type received: $5"				
			else
				func_Logger "ERROR" "Inside Other argument check module  - incorrect value of load type received: $5"
				func_Logger "ERROR" "Exiting rest of the Argument Check module with exit code 1"
				func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
				exit -1
			fi
		else
			func_Logger "ERROR" "Inside Other argument check module  - incorrect format of ODATE received from Control-M: $2"
			func_Logger "ERROR" "Exiting rest of the Argument Check module with exit code 1"
			func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
			exit -1
		fi
	else
		func_Logger "ERROR" "Inside Other argument check module  - correct Number of argument received from control M: $#"
		func_Logger "ERROR" "Exiting rest of the Argument Check module with exit code 1"
		func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
		exit -1	
	fi
else	
	func_Logger "ERROR" "LogicalDatasetType from Control-M: $1 is incorrect. Must be DATAANDCTRLFILE  or DATAFILE"
	func_Logger "ERROR" "Exiting rest of the Argument Check module with exit code 1"
	func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
	exit -1
fi



############################
##  MAIN FINCTION
############################

if [ $sLogicalDatasetType == 'DATAANDCTRLFILE' ]
then

	sODATE=$2
	sDataFilePattern=$3
	sControlFilePattern=$4
	sLoad_type=$5
	sSource=`echo $sDataFilePattern | cut -d"_" -f1|tr '[:upper:]' '[:lower:]'`

	func_Logger "INFO" "Extracting source Information .."
	func_Logger "INFO" "Source Name extracted as: $sSource"
	func_Logger "INFO" "ODATE from Control-M: $sODATE"
	func_Logger "INFO" "DataFilePattern from Control-M: $sDataFilePattern"
	func_Logger "INFO" "ControlFilePattern from Control-M: $sControlFilePattern"
	

	sLandingDir=$cInboundDir$sSource"/landing/"
	sPendingDir=$cInboundDir$sSource"/pending/"
	sErrorDir=$cInboundDir$sSource"/error/"
	sDataFilePart=`echo $sDataFilePattern | sed 's/*/'*"$sODATE"*'/g'|cut -d"_" -f2-`
	sControlFilePart=`echo $sControlFilePattern | sed 's/*/'*"$sODATE"*'/g'|cut -d"_" -f2-`
	
	func_Logger "INFO" "DATA FILE Pattern to be searched: $sDataFilePart"
	func_Logger "INFO" "CONTROL FILE Pattern to be searched: $sControlFilePart"
	
	# File and control file check for same timestamp
	func_Logger "INFO" "DATA FILE Pattern and CONTROL FILE is being searched....."
	cd $sLandingDir
	if [ `ls -lrt | awk '{print $9}'|grep $sDataFilePart|wc -l` == 1 -a `ls -lrt | awk '{print $9}'|grep $sControlFilePart|wc -l` == 1 ]
	then
	
		# SET All the variable up
		func_Logger "INFO" "Single occurrence of the data file pattern and control file confirmed in Landing directory $sLandingDir."	
		sRun_type="auto"
		sDataset_type="file"
		sDataset_name=`echo $sDataFilePattern|cut -d"*" -f1|tr '[:upper:]' '[:lower:]'`
		sCluster_type="operation"
		#defined earlier ---  sSource=`echo $sDataFilePattern | cut -d"_" -f1|tr '[:upper:]' '[:lower:]'`
		sSource_table=`echo $sDataFilePattern|cut -d"*" -f1|tr '[:upper:]' '[:lower:]'`
		sDataFileName=`ls -lrt | awk '{print $9}'|grep $sDataFilePart`
		sCurrent_extct_time=`echo "${sDataFileName//[!0-9]/}"|awk '{printf "%-14s\n", $0}'|tr ' ' '0'`
		sDataFileSize=`ls -lrt | grep $sDataFileName | awk '{print $5}'`
		sLast_timestamp="NA"
		sControlFileName=`ls -lrt | awk '{print $9}'|grep $sControlFilePart`
		sStorage="hdfs"
		
		###### HBASE LOGGING FOR START ##############
		func_HBASE_Logger "$sDataset_name" "$sDataset_name" "$sCurrent_extct_time" "$sStorage" "$sDataset_type" "$sDataFileName" 'INFO' 'START' 'Ingestion Process Triggered' "$cConfigDir"
		#############################################
		
		func_move_file $sLandingDir$sDataFileName $sPendingDir$sDataFileName
		func_move_file $sLandingDir$sControlFileName $sPendingDir$sControlFileName
		
		func_Logger "INFO" "Calling the Ingestion module with the following arguments"	
		exec_text="$sRun_type $sLoad_type $sDataset_type $sDataset_name $sCluster_type $sSource $sSource_table $sCurrent_extct_time $sDataFileName $sDataFileSize $sLast_timestamp $sControlFileName"
		func_Logger "INFO" "Calling bdpMasterWrapper.sh... "	
		func_Logger "INFO" "Argument Supplied: $exec_text"
		
		# Call the ingestion Wrapper ##
		sScript=$cCodeDir"bdpMasterWrapper.sh"
		#echo "$sScript" "'$sRun_type'" "'$sLoad_type'" "'$sDataset_type'" "'$sDataset_name'" "'$sCluster_type'" "'$sSource'" "'$sSource_table'" "$sCurrent_extct_time" "'$sDataFileName'" "$sDataFileSize" "'$sLast_timestamp'" "'$sControlFileName'"
		sh "$sScript" "$sRun_type" "$sLoad_type" "$sDataset_type" "$sDataset_name" "$sCluster_type" "$sSource" "$sSource_table" "$sCurrent_extct_time" "$sDataFileName" "$sDataFileSize" "$sLast_timestamp" "$sControlFileName"
		if [ $? == 0 ]
		then	
			func_Logger "INFO" "Ingestion module ran successfully."	
			###### HBASE LOGGING FOR SUCCESSFUL COMPLETION ##############
			func_HBASE_Logger "$sDataset_name" "$sDataset_name" "$sCurrent_extct_time" "$sStorage" "$sDataset_type" "$sDataFileName" 'SUCCESS' 'END' 'Ingestion Process Completed Successfully.' "$cConfigDir"
			#############################################
			func_Logger 'INFO' '########## COMPLETING Control M wrapper Script ############'
		else
			func_Logger "ERROR" "Error in the ingestion module. check Ingestion module logs for details"
			###### HBASE LOGGING FOR FAILURE COMPLETION ##############
			func_HBASE_Logger "$sDataset_name" "$sDataset_name" "$sCurrent_extct_time" "$sStorage" "$sDataset_type" "$sDataFileName" 'ERROR' 'END' 'Ingestion Process completed unsuccessfully.' "$cConfigDir"
			#############################################
			func_Logger "ERROR" "Exiting Ingestion Calling module with exit code 1"
			func_Logger 'INFO' '########## COMPLETING Control M wrapper Script with errors ############'
			exit -1
		fi
	else
		func_Logger "ERROR" "Multiple/No instances of the ODATE file exist in the inbound location"
		func_Logger "ERROR" "Moving file to error directory in case it exists and Exiting module with exit code 1"
		
		if [ `ls -lrt $sDataFilePart|wc -l` -gt 1 ]
		then
			for sErrDataFile in `ls -1 $sDataFilePart`
			do 
				func_move_file $sErrDataFile $sErrorDir
			done
		else 
			func_Logger "WARN" "No Data file present to move to error directory."
		fi
		
		
		if [ `ls -lrt $sControlFilePart|wc -l` -gt 1 ]
		then
			for sErrCtrlFile in `ls -1 $sControlFilePart`
			do 
				func_move_file $sErrCtrlFile $sErrorDir
			done
		else 
			func_Logger "WARN" "No Control file present to move to error directory."
		fi
		exit -1
	fi		
else
	func_Logger "ERROR" "function for other types to be included"
fi
